import 'package:emprestimos_app/models/cliente.dart';
import 'package:emprestimos_app/models/request_emprestimo.dart';
import 'package:emprestimos_app/providers/parametros_provider.dart';
import 'package:emprestimos_app/screens/emprestimos/emprestimo_create_step2.dart';
import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:emprestimos_app/widgets/emprestimo_form.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class EmprestimoCreateStep1 extends StatefulWidget {
  final Cliente? cliente;

  const EmprestimoCreateStep1({Key? key, required this.cliente})
      : super(key: key);

  @override
  State<EmprestimoCreateStep1> createState() => _EmprestimoCreateStep1State();
}

class _EmprestimoCreateStep1State extends State<EmprestimoCreateStep1> {
  bool isSimulation = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      isSimulation = widget.cliente == null;
      _carregarParametros();
    });
  }

  void _carregarParametros() async {
    final provider = Provider.of<ParametroProvider>(context, listen: false);
    if (provider.parametrosCliente.isEmpty) {
      if (widget.cliente != null) {
        await provider.buscarParametrosCliente(widget.cliente!.id!);
      }
    }
    if (provider.parametrosEmpresa.isEmpty) {
      await provider.buscarParametrosEmpresa();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ParametroProvider>(
        builder: (context, parametroProvider, _) {
      return Scaffold(
        appBar: AppBar(
          title: Text(isSimulation ? "Simular Empréstimo" : "Novo Empréstimo"),
        ),
        body: Padding(
          padding:
              const EdgeInsets.all(16.0), // 🔹 Adiciona um espaçamento ao redor
          child: AppBackground(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  EmprestimoForm(
                    parametrosCliente: parametroProvider.parametrosCliente,
                    parametrosEmpresa: parametroProvider.parametrosEmpresa,
                    isSimulation: isSimulation,
                    onSubmit: (valor, juros, parcelas, tipoPagamento, penhora) {
                      final dto = NovoEmprestimoDTO(
                          valor: valor,
                          juros: juros,
                          numeroParcelas: parcelas,
                          tipoPagamento: tipoPagamento,
                          cliente: widget.cliente,
                          penhora: penhora);

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              EmprestimoCreateStep2(emprestimoDraft: dto),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}
