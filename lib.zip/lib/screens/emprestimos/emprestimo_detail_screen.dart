import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/core/data_utils.dart';
import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/models/baixa_parcela_result.dart';
import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:emprestimos_app/widgets/card_penhora_widget.dart';
import 'package:emprestimos_app/widgets/custom_button.dart';
import 'package:emprestimos_app/widgets/dialog_widget.dart';
import 'package:emprestimos_app/widgets/edit_message_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../../models/emprestimo.dart';
import '../../models/parcela.dart';
import '../../providers/emprestimo_provider.dart';
import 'package:emprestimos_app/widgets/dialog_parcela.dart';

class EmprestimoDetailScreen extends StatefulWidget {
  final EmprestimoDTO? emprestimo;
  final int? emprestimoId;

  const EmprestimoDetailScreen({Key? key, this.emprestimo, this.emprestimoId})
      : super(key: key);

  @override
  State<EmprestimoDetailScreen> createState() => _EmprestimoDetailScreenState();
}

class _EmprestimoDetailScreenState extends State<EmprestimoDetailScreen> {
  late List<bool> _selectedParcelas;
  EmprestimoDTO? _emprestimo;

  @override
  void initState() {
    super.initState();

    if (widget.emprestimo != null) {
      _emprestimo = widget.emprestimo;
      _initializeParcelas();
    } else {
      _fetchEmprestimo();
    }
  }

  Future<void> _fetchEmprestimo() async {
    if (widget.emprestimoId == null) return;

    try {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final emprestimoProvider =
            Provider.of<EmprestimoProvider>(context, listen: false);
        final emprestimo = await emprestimoProvider
            .buscarEmprestimoPorId(widget.emprestimoId!);
        if (emprestimo != null) {
          setState(() {
            _emprestimo = emprestimo;
            _initializeParcelas();
          });
        }
      });
    } catch (e) {
      debugPrint("Erro ao buscar empréstimo: $e");
    }
  }

  void _initializeParcelas() {
    if (_emprestimo != null) {
      _selectedParcelas =
          List.generate(_emprestimo!.parcelas.length, (index) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<EmprestimoProvider>(
        builder: (context, emprestimoProvider, child) {
      if (emprestimoProvider.errorMessage != null) {
        return Center(child: Text(emprestimoProvider.errorMessage!));
      }

      if (_emprestimo == null || emprestimoProvider.isLoading) {
        return const Scaffold(
          body: Center(child: CircularProgressIndicator()),
        );
      }

      return Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Contrato: #${_emprestimo!.id}",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Cliente: ${Util.getPrimeiroNome(_emprestimo!.cliente.nome ?? 'Sem Nome')}",
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          backgroundColor: AppTheme.primaryColor,
          elevation: 0,
        ),
        // appBar: AppBar(
        //   title: Text(_emprestimo != null
        //       ? "Empréstimo #${_emprestimo!.id}"
        //       : "Carregando..."),
        // ),
        body: _emprestimo == null || emprestimoProvider.isLoading
            ? const Center(child: CircularProgressIndicator())
            : AppBackground(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildCabecalho(emp: _emprestimo!),
                      if (_emprestimo?.penhora != null) ...[
                        CardInfoPenhoraWidget(penhora: _emprestimo!.penhora!)
                      ],
                      const SizedBox(height: 8),
                      _buildListaParcelas(_emprestimo!),
                      if (_emprestimo?.penhora != null &&
                          _emprestimo?.penhora!.status != 'EXECUTADA') ...[
                        CustomButton(
                            text: 'Executar Penhora',
                            onPressed:
                                _dialogConfirmacaoQuitarEmprestimoPenhora),
                      ],
                      const SizedBox(height: 8),
                      if (_emprestimo?.statusEmprestimo != 'QUITADO') ...[
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: CustomButton(
                            text: 'Baixar parcela',
                            onPressed: () => _abrirDialogBaixa(),
                            backgroundColor:
                                Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
        floatingActionButton: (_emprestimo?.statusEmprestimo != 'QUITADO')
            ? FloatingActionButton(
                onPressed: _abrirWhatsapp,
                backgroundColor: Colors.green,
                child: Icon(FontAwesomeIcons.whatsapp),
                tooltip: 'Cobrar no WhatsApp',
              )
            : null,
      );
    });
  }

  void _dialogConfirmacaoQuitarEmprestimoPenhora() {
    MyAwesomeDialog(
            dialogType: DialogType.question,
            context: context,
            btnOkText: 'Sim',
            onCancelPressed: () {
              return;
            },
            onOkPressed: () => _quitarEmprestimoPenhora(),
            btnCancelText: 'Não',
            title: "Atenção",
            message:
                'Você tem certeza que deseja executar esta penhora ? este processo é irreversivel')
        .show();
  }

  Future<void> _quitarEmprestimoPenhora() async {
    final provider = Provider.of<EmprestimoProvider>(listen: false, context);
    await provider.quitarEmprestimoComPenhora(_emprestimo!.id).then((value) {
      if (provider.errorMessage != null) {
        MyAwesomeDialog(
                dialogType: DialogType.error,
                context: context,
                btnCancelText: 'Ok',
                title: "Ops, algo deu errado!",
                message: provider.errorMessage!)
            .show();
      } else {
        setState(() {
          _emprestimo = value;
        });
      }
    });
  }

  Widget _buildCabecalho({required EmprestimoDTO emp}) {
    final totalParcelas = emp.parcelas.length;
    final parcelasPagas = emp.parcelas.where((p) => p.status == "PAGA").length;

    final valorEmprestimo = emp.valor;
    final totalJuros =
        emp.parcelas.fold(0.0, (sum, p) => sum + (p.jurosParcela ?? 0.0));
    final valorTotalComJuros = valorEmprestimo + totalJuros;
    final jurosPagos = emp.parcelas
        .expand((p) => p.baixas ?? [])
        .fold(0.0, (sum, b) => sum + (b.tipoBaixa == "JUROS" ? b.valor : 0.0));
    final totalPago = emp.parcelas
        .expand((p) => p.baixas ?? [])
        .fold(0.0, (sum, b) => sum + b.valor);

    return SafeArea(
      bottom: false,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(16, 5, 16, 20),
        decoration: const BoxDecoration(
          color: AppTheme.primaryColor,
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(25),
            bottomRight: Radius.circular(25),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Scroll das linhas de informações
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Column(
                children: [
                  _buildInfoRowScroll([
                    _buildInfoItem(Icons.monetization_on, "Emprestado",
                        Util.formatarMoeda(valorEmprestimo)),
                    _buildInfoItem(Icons.attach_money, "Total com Juros",
                        Util.formatarMoeda(valorTotalComJuros)),
                    _buildInfoItem(Icons.percent, "Tx. Juros",
                        "${emp.juros.toStringAsFixed(1)}%"),
                  ]),
                  _buildInfoRowScroll([
                    _buildInfoItem(Icons.paid, "Total Pago",
                        Util.formatarMoeda(totalPago)),
                    _buildInfoItem(Icons.check_circle, "Parcelas Pagas",
                        "$parcelasPagas/$totalParcelas"),
                    _buildInfoItem(Icons.trending_up, "Juros Pago",
                        Util.formatarMoeda(jurosPagos)),
                  ]),
                  _buildInfoRowScroll([
                    _buildInfoItem(Icons.info, "Status", emp.statusEmprestimo),
                    _buildInfoItem(
                        Icons.calendar_today, "Tipo", emp.tipoPagamento),
                    if (emp.cobradorNome != null)
                      _buildInfoItem(Icons.person, "Cobrador",
                          Util.getPrimeiroNome(emp.cobradorNome!)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRowScroll(List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: children
            .map((child) => Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: child,
                ))
            .toList(),
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value) {
    return SizedBox(
      width: 110,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 28),
          const SizedBox(height: 6),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 4),
          Text(value,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  // Widget _buildInfoItem(IconData icon, String label, String value) {
  //   return Column(
  //     mainAxisSize: MainAxisSize.min,
  //     children: [
  //       Icon(icon, color: Colors.white, size: 28),
  //       const SizedBox(height: 6),
  //       Text(label,
  //           style: const TextStyle(color: Colors.white70, fontSize: 14)),
  //       const SizedBox(height: 4),
  //       Text(value,
  //           style: const TextStyle(
  //               color: Colors.white,
  //               fontSize: 16,
  //               fontWeight: FontWeight.bold)),
  //     ],
  //   );
  // }

  Widget _buildListaParcelas(EmprestimoDTO emp) {
    final parcelas = emp.parcelas;

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: parcelas.length,
      itemBuilder: (context, index) {
        final parc = parcelas[index];
        final isSelected = _selectedParcelas[index];

        return Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 3,
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: Util.getGradientForStatus(
                  parc.status), // Define o fundo com base no status
            ),
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Cabeçalho da parcela
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Parcela ${parc.numeroParcela}",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text.rich(
                          TextSpan(
                            children: [
                              const TextSpan(
                                text: "Valor: ",
                                style: TextStyle(
                                    fontSize: 14, color: Colors.white70),
                              ),
                              TextSpan(
                                text: Util.formatarMoeda(parc.valor),
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Transform.scale(
                          scale: 1.4,
                          child: Checkbox(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            side: BorderSide(
                              color: Util.getStatusColor(parc.status),
                              width: 2,
                            ),
                            checkColor: Colors.white,
                            activeColor: Util.getStatusColor(parc.status),
                            value: isSelected,
                            onChanged: parc.status == "PAGA"
                                ? null
                                : (bool? checked) {
                                    setState(() {
                                      _selectedParcelas[index] =
                                          checked ?? false;
                                    });
                                  },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                const Divider(color: Colors.white38),

                // Datas de vencimento e pagamento
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildInfoItem(Icons.event, "Vencimento",
                        FormatData.formatarDataCompleta(parc.dataVencimento)),
                    _buildInfoItem(
                        Icons.history,
                        "Pagamento",
                        parc.dataPagamento != null
                            ? FormatData.formatarDataHora(parc.dataPagamento)
                            : "--"),
                  ],
                ),

                // Se houver baixas, mostrar abaixo com ExpansionTile
                if (parc.baixas != null && parc.baixas!.isNotEmpty) ...[
                  const Divider(color: Colors.white38),
                  ExpansionTile(
                    tilePadding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), // Cantos arredondados
                      side: const BorderSide(
                          color: Colors.white24, width: 1), // Borda sutil
                    ),
                    collapsedBackgroundColor: Colors.white.withOpacity(0.1),
                    backgroundColor: Colors.white.withOpacity(0.15),
                    iconColor: Colors.white, // Cor do ícone expandido
                    collapsedIconColor: Colors.white70, // Cor do ícone fechado

                    title: const Text(
                      "Baixas Registradas",
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    ),

                    trailing: const Icon(Icons.keyboard_arrow_down_rounded,
                        size: 28, color: Colors.white),

                    children: parc.baixas!
                        .map((b) => ListTile(
                              leading: const Icon(Icons.attach_money,
                                  size: 20, color: Colors.greenAccent),
                              title: Text(
                                "${Util.formatarMoeda(b.valor)} - ${b.tipoBaixa}",
                                style: const TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                              subtitle: Text(
                                "Pago em ${FormatData.formatarDataComMesExtenso(b.dataPagamento)}  ${b.cobradorNome != null ? "por ${Util.getPrimeiroNome(b.cobradorNome!)}" : ""}",
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.white70,
                                ),
                              ),
                            ))
                        .toList(),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  void _abrirDialogBaixa() async {
    final parcelasSelecionadas = <ParcelaDTO>[];
    for (int i = 0; i < _selectedParcelas.length; i++) {
      if (_selectedParcelas[i]) {
        parcelasSelecionadas.add(_emprestimo!.parcelas[i]);
      }
    }

    if (parcelasSelecionadas.isEmpty) {
      MyAwesomeDialog(
          context: context,
          message: 'Selecione ao menos uma parcela para dar baixa.',
          title: 'Atenção',
          dialogType: DialogType.info,
          btnOkText: 'Ok',
          onOkPressed: () => {}).show();
      return;
    }
    final resultado = await showDialog<BaixaParcelaResult>(
      context: context,
      builder: (_) =>
          DialogBaixaParcelas(parcelasSelecionadas: parcelasSelecionadas),
    );

    tratarRetornoBaixa(resultado, parcelasSelecionadas);
  }

  void tratarRetornoBaixa(BaixaParcelaResult? resultado,
      List<ParcelaDTO> parcelasSelecionadas) async {
    final provider = Provider.of<EmprestimoProvider>(context, listen: false);

    if (resultado == null) return;
    if (resultado.sucesso == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            "Baixa registrada com sucesso!",
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ),
      );

      final emprestimoAtualizado =
          await provider.buscarEmprestimoPorId(_emprestimo!.id);
      parcelasSelecionadas.clear();
      if (emprestimoAtualizado != null) {
        setState(() {
          _emprestimo = emprestimoAtualizado;
          _selectedParcelas =
              List.generate(_emprestimo!.parcelas.length, (index) => false);
        });
      }
    } else {
      MyAwesomeDialog(
        context: context,
        message: resultado.mensagemErro ?? "Erro ao registrar baixa",
        title: 'Atenção',
        dialogType: DialogType.error,
        btnOkText: 'Ok',
        onOkPressed: () => {},
      ).show();
    }
  }

  void _abrirWhatsapp() async {
    final parcelasSelecionadas = <ParcelaDTO>[];
    for (int i = 0; i < _selectedParcelas.length; i++) {
      if (_selectedParcelas[i]) {
        parcelasSelecionadas.add(_emprestimo!.parcelas[i]);
      }
    }

    if (parcelasSelecionadas.isEmpty) {
      MyAwesomeDialog(
          context: context,
          message:
              'Selecione ao menos uma parcela para enviar mensagem no WhatsApp.',
          title: 'Atenção',
          dialogType: DialogType.info,
          btnOkText: 'Ok',
          onOkPressed: () => {}).show();

      return;
    }

    final ParcelaDTO parcela = parcelasSelecionadas.first;
    final String nomeCliente =
        _emprestimo!.cliente.nome ?? "Cliente Desconhecido";
    final String telefoneCliente = _emprestimo!.cliente.telefone ?? "";
    final String numeroParcela = parcela.numeroParcela.toString();
    final String valorParcela = Util.formatarMoeda(parcela.valor);
    final String dataVencimento =
        FormatData.formatarDataCompleta(parcela.dataVencimento);

    String mensagemPadrao = """
Olá $nomeCliente,

Estamos entrando em contato para lembrar que sua parcela nº $numeroParcela no valor de $valorParcela venceu em $dataVencimento.

Por favor, nos informe sobre o pagamento ou entre em contato para mais informações.

Aguardamos seu retorno!
""";

    if (telefoneCliente.isEmpty) {
      MyAwesomeDialog(
          context: context,
          message: 'Este cliente não possui um telefone cadastrado.',
          title: 'Atenção',
          dialogType: DialogType.error,
          btnOkText: 'Ok',
          onOkPressed: () => {}).show();
      return;
    }

    TextEditingController mensagemController =
        TextEditingController(text: mensagemPadrao);

    showEditMessageDialog(
        context: context,
        mensagemController: mensagemController,
        telefoneCliente: telefoneCliente);
  }
}
