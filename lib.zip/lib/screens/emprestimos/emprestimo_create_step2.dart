import 'package:dropdown_search/dropdown_search.dart';
import 'package:emprestimos_app/core/data_utils.dart';
import 'package:emprestimos_app/core/role.dart';
import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/models/cliente.dart';
import 'package:emprestimos_app/models/parcela_simulada.dart';
import 'package:emprestimos_app/models/request_emprestimo.dart';
import 'package:emprestimos_app/providers/auth_provider.dart';
import 'package:emprestimos_app/providers/emprestimo_provider.dart';
import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/providers/parametros_provider.dart';
import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:emprestimos_app/widgets/cliente_dropdown_search.dart';
import 'package:emprestimos_app/widgets/custom_button.dart';
import 'package:emprestimos_app/widgets/resumo_penhora_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class EmprestimoCreateStep2 extends StatefulWidget {
  final NovoEmprestimoDTO emprestimoDraft;

  const EmprestimoCreateStep2({Key? key, required this.emprestimoDraft})
      : super(key: key);

  @override
  State<EmprestimoCreateStep2> createState() => _EmprestimoCreateStep2State();
}

class _EmprestimoCreateStep2State extends State<EmprestimoCreateStep2> {
  List<ParcelaSimulada> _parcelasSimuladas = [];
  late TextEditingController _parcelaController;
  double _jurosCalculado = 0.0;
  bool _mostrarJuros = false;
  String? _erroCliente;

  Cliente? _clienteSelecionado;
  @override
  void initState() {
    super.initState();
    _simularParcelas();
    _setCliente();
  }

  void _setCliente() {
    if (widget.emprestimoDraft.cliente != null) {
      Future.delayed(Duration.zero, () {
        if (mounted) {
          setState(() {
            _clienteSelecionado = widget.emprestimoDraft.cliente;
          });
        }
      });
    }
  }

  void _simularParcelas() {
    final valor = widget.emprestimoDraft.valor;
    final juros = widget.emprestimoDraft.juros;
    final tipo = widget.emprestimoDraft.tipoPagamento;
    final n = widget.emprestimoDraft.numeroParcelas;

    final taxaDecimal = juros / 100;
    final totalJuros = valor * taxaDecimal;
    final totalPagar = valor + totalJuros;
    final valorParcela = totalPagar / n;

    _parcelaController = TextEditingController(
      text: Util.formatarMoeda(valorParcela),
    );

    DateTime dataBase = DateTime.now();
    final temp = <ParcelaSimulada>[];

    for (int i = 1; i <= n; i++) {
      if (tipo == "MENSAL") {
        dataBase = DateTime(dataBase.year, dataBase.month + 1, dataBase.day);
      } else if (tipo == "SEMANAL") {
        dataBase = dataBase.add(const Duration(days: 7));
      } else if (tipo == "DIARIO") {
        dataBase = dataBase.add(const Duration(days: 1));
      }

      temp.add(
        ParcelaSimulada(
          numero: i,
          valor: valorParcela,
          dataVencimento: dataBase,
        ),
      );
    }

    setState(() {
      _parcelasSimuladas = temp;
      _jurosCalculado = juros;
    });
  }

  /// 🔹 Recalcula a taxa de juros com base no novo valor da parcela
  void _recalcularJuros() {
    double novoValorParcela = Util.removerMascaraValor(_parcelaController.text);

    if (novoValorParcela <= 0) return;

    final valorEmprestimo = widget.emprestimoDraft.valor;
    final numParcelas = widget.emprestimoDraft.numeroParcelas;

    // Calculando os novos juros com a fórmula reversa
    double novoJuros = (((novoValorParcela * numParcelas) - valorEmprestimo) /
            valorEmprestimo) *
        100;

    setState(() {
      _jurosCalculado = novoJuros;
    });
  }

  @override
  Widget build(BuildContext context) {
    final draft = widget.emprestimoDraft;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Pré-visualização do Empréstimo"),
        backgroundColor: AppTheme.primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: AppBackground(
          child: Column(
            children: [
              _buildResumoEmprestimo(draft),
              const SizedBox(height: 16),
              (_clienteSelecionado == null || _erroCliente != null)
                  ? Column(
                      children: [
                        ClienteDropdown(
                          onClienteSelecionado: (cliente) async {
                            final isValido = await _validaClienteTemp(cliente);
                            if (mounted && isValido) {
                              setState(() {
                                _clienteSelecionado = cliente;
                                _erroCliente = null;
                              });
                            }
                          },
                        ),
                        if (_erroCliente != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              _erroCliente!,
                              style: const TextStyle(
                                  color: Colors.red, fontSize: 12),
                            ),
                          ),
                        const SizedBox(height: 16),
                      ],
                    )
                  : const SizedBox.shrink(),
              ResumoPenhoraWidget(
                emprestimo: draft,
              ),
              const SizedBox(height: 16),
              _buildAjusteParcelas(),
              _buildListaParcelas(),
              const SizedBox(height: 16),
              _buildBotoes(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResumoEmprestimo(NovoEmprestimoDTO draft) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          gradient: AppTheme.primaryGradient,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 Informações principais organizadas em um grid compacto
            Wrap(
                spacing: 12, // Espaço entre os itens
                runSpacing: 8, // Espaço entre linhas
                alignment: WrapAlignment.start,
                children: [
                  _buildInfoItem(Icons.monetization_on, "Valor",
                      Util.formatarMoeda(draft.valor)),
                  if (_mostrarJuros)
                    _buildInfoItem(Icons.percent, "Juros",
                        "${_jurosCalculado.toStringAsFixed(2)}%"),
                  _buildInfoItem(Icons.calendar_today, "Parcelas",
                      "${draft.numeroParcelas}x"),
                  // _buildInfoItem(Icons.attach_money, "Parcela",
                  //     Util.formatarMoeda((_parcelasSimuladas.first.valor))),
                ]),

            const SizedBox(height: 8),

            // 🔹 Dados do Cliente, se estiver selecionado
            if (_clienteSelecionado != null)
              Wrap(
                spacing: 12,
                runSpacing: 8,
                children: [
                  _buildInfoItem(Icons.person, "Cliente",
                      _clienteSelecionado?.nome ?? "Não selecionado"),
                  _buildInfoItem(Icons.phone, "Telefone",
                      _clienteSelecionado?.telefone ?? "Não informado"),
                ],
              ),

            // 🔹 Botão para mostrar/ocultar juros sem ocupar muito espaço
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  setState(() {
                    _mostrarJuros = !_mostrarJuros;
                  });
                },
                child: Text(
                  _mostrarJuros ? "Ocultar Juros" : "Mostrar Juros",
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 🔹 Campo para ajuste da parcela
  Widget _buildAjusteParcelas() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: _parcelaController,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(
          labelText: "Ajustar Valor da Parcela",
          border: OutlineInputBorder(),
        ),
        onChanged: (value) => _recalcularJuros(),
      ),
    );
  }

  /// 🔹 Lista de Parcelas Simuladas
  Widget _buildListaParcelas() {
    return Expanded(
      child: ListView.builder(
        itemCount: _parcelasSimuladas.length,
        itemBuilder: (context, index) {
          final parc = _parcelasSimuladas[index];
          return Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 3,
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppTheme.secondaryColor,
                child: Text(
                  "${parc.numero}",
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
              title: Text(
                Util.formatarMoeda(
                    Util.removerMascaraValor(_parcelaController.text)),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                "Vencimento: ${FormatData.formatarDataCompleta(parc.dataVencimento.toString())}",
                style: const TextStyle(color: Colors.grey),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBotoes() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        OutlinedButton.icon(
          icon: const Icon(Icons.arrow_back),
          label: const Text("Voltar"),
          onPressed: () => Navigator.pop(context),
        ),
        CustomButton(
            text: 'Confirmar',
            enabled: _erroCliente == null && _clienteSelecionado != null,
            onPressed: () {
              if (_erroCliente == null) {
                _validaClienteTemp(_clienteSelecionado!);
                _confirmarEmprestimo();
              }
            }),
      ],
    );
  }

  Future<void> _valida() async {
    if (_clienteSelecionado == null) {
      setState(() {
        _erroCliente = "Selecione um cliente antes de continuar.";
      });
      return;
    }

    final provider = Provider.of<ParametroProvider>(context, listen: false);

    await Provider.of<ParametroProvider>(context, listen: false)
        .buscarParametrosEmpresa();

    await Provider.of<ParametroProvider>(context, listen: false)
        .buscarParametrosCliente(_clienteSelecionado!.id!);

    final qtdEmprestimosAtivos =
        await Provider.of<EmprestimoProvider>(context, listen: false)
            .countEmprestimosCliente(_clienteSelecionado!.id!);

    double valorEmprestimo = widget.emprestimoDraft.valor;
    int numeroParcelas = widget.emprestimoDraft.numeroParcelas;
    double juros = _jurosCalculado;

    double? limiteCreditoCliente = Util.getParametroDouble(
        'LIMITE_CREDITO_CLIENTE', provider.parametrosCliente);
    double? limiteCreditoEmpresa = Util.getParametroDouble(
        'LIMITE_EMPRESTIMO', provider.parametrosEmpresa);

    double? limiteCredito = limiteCreditoCliente ?? limiteCreditoEmpresa;

    int? limiteQtdEmprestimosCliente = Util.getParametroInt(
        'LIMITE_EMPRESTIMO_CLIENTE', provider.parametrosCliente);
    int? limiteQtdEmprestimosEmpresa = Util.getParametroInt(
        'LIMITE_EMPRESTIMO_CLIENTE', provider.parametrosEmpresa);

    int? limiteQtdEmprestimos =
        limiteQtdEmprestimosCliente ?? limiteQtdEmprestimosEmpresa;

// 🔹 Verifica limite de crédito
    if (limiteCredito != null && valorEmprestimo > limiteCredito) {
      setState(() {
        _erroCliente =
            "Valor excede o limite de crédito permitido: ${Util.formatarMoeda(limiteCredito)}";
      });
      return;
    }

// 🔹 Verifica limite de empréstimos em aberto
    if (limiteQtdEmprestimos != null &&
        qtdEmprestimosAtivos!.emprestimos > limiteQtdEmprestimos) {
      setState(() {
        _erroCliente =
            "Número de empréstimos em aberto excede o permitido (${limiteQtdEmprestimos}).";
      });
      return;
    }

    // Limpa erro se passou na validação
    setState(() {
      _erroCliente = null;
    });
  }

  Future<bool> _validaClienteTemp(Cliente cliente) async {
    final provider = Provider.of<ParametroProvider>(context, listen: false);

    bool isValido = true;
    final erros = StringBuffer();

    await provider.buscarParametrosEmpresa();
    await provider.buscarParametrosCliente(cliente.id!);

    final qtdEmprestimosAtivos =
        await Provider.of<EmprestimoProvider>(context, listen: false)
            .countEmprestimosCliente(cliente.id!);

    int limiteQtdEmprestimos = 0;
    double limiteCredito = 0.0;

    double valorEmprestimo = widget.emprestimoDraft.valor;
    int numeroParcelas = widget.emprestimoDraft.numeroParcelas;
    double juros = _jurosCalculado;

    double? limiteCreditoCliente = Util.getParametroDouble(
        'LIMITE_CREDITO_CLIENTE', provider.parametrosCliente);
    double? limiteCreditoEmpresa = Util.getParametroDouble(
        'LIMITE_EMPRESTIMO', provider.parametrosEmpresa);

    int limiteQtdEmprestimosCliente = Util.getParametroInt(
        'LIMITE_EMPRESTIMO_CLIENTE', provider.parametrosCliente);
    int limiteQtdEmprestimosEmpresa = Util.getParametroInt(
        'LIMITE_EMPRESTIMO_CLIENTE', provider.parametrosEmpresa);

    if (limiteQtdEmprestimosCliente > 0) {
      limiteQtdEmprestimos = limiteQtdEmprestimosCliente;
    } else if (limiteQtdEmprestimosEmpresa > 0) {
      limiteQtdEmprestimos = limiteQtdEmprestimosEmpresa;
    } else {
      limiteQtdEmprestimos = 0;
    }

    if (limiteCreditoCliente > 0.0) {
      limiteCredito = limiteCreditoCliente;
    } else if (limiteCreditoEmpresa > 0) {
      limiteCredito = limiteCreditoEmpresa;
    } else {
      limiteCredito = 0;
    }

    if (limiteCredito != 0 && valorEmprestimo > limiteCredito) {
      erros.writeln(
          "Valor excede o limite de crédito permitido: ${Util.formatarMoeda(limiteCredito)}");
      isValido = false;
    }

    if (limiteQtdEmprestimos != 0 &&
        qtdEmprestimosAtivos!.emprestimos >= limiteQtdEmprestimos) {
      erros.writeln(
          "Número de empréstimos em aberto excede o permitido (${limiteQtdEmprestimos}).");
      isValido = false;
    }

    if (!isValido) {
      setState(() {
        _erroCliente = erros.toString().trim();
      });
      return false;
    }

    return true;
  }

  Future<void> _validarAntesDeConfirmar() async {
    await _valida(); // executa a validação primeiro

    if (_erroCliente == null) {
      _confirmarEmprestimo();
    }
  }

  /// 🔹 Confirma o empréstimo e retorna à tela anterior
  void _confirmarEmprestimo() async {
    final emprestimoProvider =
        Provider.of<EmprestimoProvider>(context, listen: false);

    widget.emprestimoDraft.juros = _jurosCalculado;
    widget.emprestimoDraft.cliente = _clienteSelecionado;

    final novoEmprestimo =
        await emprestimoProvider.criarEmprestimo(widget.emprestimoDraft);

    if (!mounted) return;

    if (novoEmprestimo == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Erro ao criar empréstimo"),
            backgroundColor: Colors.red),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Empréstimo criado com sucesso!"),
            backgroundColor: Colors.green),
      );
      await Future.delayed(const Duration(milliseconds: 300));
      if (!mounted) return;
      Navigator.pop(context);
      Navigator.pop(context, novoEmprestimo);
    }
  }
}

/// 🔹 Helper: Informações do Resumo
Widget _buildInfoRow(List<Widget> items) {
  return Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: items,
    ),
  );
}

Widget _buildInfoItem(IconData icon, String label, String value) {
  return Row(
    mainAxisSize: MainAxisSize.min, // Mantém os itens compactos
    children: [
      Icon(icon, color: Colors.white70, size: 20),
      const SizedBox(width: 4),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    ],
  );
}
