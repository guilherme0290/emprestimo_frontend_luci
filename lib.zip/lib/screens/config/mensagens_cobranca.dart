import 'package:emprestimos_app/models/empresa.dart';
import 'package:emprestimos_app/models/mensagem_cobranca.dart';
import 'package:emprestimos_app/models/planos.dart';
import 'package:emprestimos_app/providers/empresa_provider.dart';
import 'package:emprestimos_app/providers/mensagens_cobranca_provider.dart';
import 'package:emprestimos_app/screens/planos/escolher_planos.dart';
import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:emprestimos_app/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MensagensCobrancaScreen extends StatefulWidget {
  const MensagensCobrancaScreen({super.key});

  @override
  State<MensagensCobrancaScreen> createState() =>
      _MensagensCobrancaScreenState();
}

class _MensagensCobrancaScreenState extends State<MensagensCobrancaScreen> {
  final Map<TipoMensagemCobranca, TextEditingController> _controllers = {};
  final Map<TipoMensagemCobranca, bool> _habilitado = {};
  Empresa? _empresa;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _carregarEmpresa();
      final provider =
          Provider.of<MensagemCobrancaProvider>(context, listen: false);
      provider.buscarMensagens().then((_) {
        for (var msg in provider.mensagens) {
          _controllers[msg.tipo] = TextEditingController(text: msg.conteudo);
          _habilitado[msg.tipo] = msg.ativo;
        }
        setState(() {});
      });
    });
  }

  @override
  void dispose() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _carregarEmpresa() {
    return Provider.of<EmpresaProvider>(context, listen: false)
        .buscarEmpresaById(null)
        .then((_) {
      setState(() {
        _empresa = Provider.of<EmpresaProvider>(context, listen: false).empresa;
      });
    });
  }

  Widget _buildMensagemCard({
    required TipoMensagemCobranca tipo,
    required String titulo,
    required String subtitulo,
  }) {
    final controller = _controllers[tipo] ?? TextEditingController();
    final ativo = _habilitado[tipo] ?? true;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(titulo,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text(subtitulo,
                          style: const TextStyle(
                              fontSize: 13, color: Colors.grey)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    if (!empresaPodeUsarWhatsapp()) {
                      _mostrarDialogPlano();
                    }
                  },
                  child: AbsorbPointer(
                    absorbing: !empresaPodeUsarWhatsapp(),
                    child: Switch(
                      value: ativo,
                      activeColor: Theme.of(context).primaryColor,
                      onChanged: (value) {
                        setState(() => _habilitado[tipo] = value);
                      },
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (ativo)
              TextField(
                controller: controller,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: "Digite a mensagem...",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
          ],
        ),
      ),
    );
  }

  bool empresaPodeUsarWhatsapp() {
    return _empresa?.plano?.incluiWhatsapp ?? false;
  }

  void _mostrarDialogPlano() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Funcionalidade indisponível"),
          content: const Text(
              "Seu plano atual não contempla o envio de mensagens por WhatsApp para cobranças automáticas. Deseja conhecer os planos disponíveis?"),
          actions: [
            TextButton(
              child: const Text("Agora não"),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text("Ver planos"),
              onPressed: () {
                Navigator.of(context).pop(); // fecha o diálogo
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const EscolherPlanoScreen()),
                );
              },
            ),
          ],
        );
      },
    );
  }

  void _salvarMensagens() async {
    final provider =
        Provider.of<MensagemCobrancaProvider>(context, listen: false);
    final mensagensAtualizadas = _controllers.entries.map((entry) {
      return MensagemCobranca(
        tipo: entry.key,
        conteudo: entry.value.text,
        ativo: _habilitado[entry.key] ?? true,
      );
    }).toList();

    await provider.salvarMensagens(mensagensAtualizadas);

    if (provider.errorMessage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(provider.successMessage!),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(provider.errorMessage ?? "Erro ao salvar mensagens"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _restaurarPadroes() async {
    final provider =
        Provider.of<MensagemCobrancaProvider>(context, listen: false);
    await provider.restaurarPadroes();
    if (provider.errorMessage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Mensagens restauradas para os padrões."),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(provider.errorMessage!),
          backgroundColor: Colors.red,
        ),
      );
    }
    setState(() {
      for (var msg in provider.mensagens) {
        _controllers[msg.tipo]?.text = msg.conteudo;
        _habilitado[msg.tipo] = msg.ativo;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<MensagemCobrancaProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text("Mensagens Personalizadas")),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : AppBackground(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  children: [
                    Card(
                      color: Colors.grey[100],
                      elevation: 1,
                      margin: const EdgeInsets.only(bottom: 20),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      child: const Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "🔖 Você pode usar os seguintes placeholders nas mensagens:",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 12),
                            Row(
                              children: [
                                Icon(Icons.label_outline, size: 20),
                                SizedBox(width: 8),
                                Expanded(
                                    child: Text("{{nome}} → Nome do cliente")),
                              ],
                            ),
                            SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.attach_money_outlined, size: 20),
                                SizedBox(width: 8),
                                Expanded(
                                    child:
                                        Text("{{valor}} → Valor da parcela")),
                              ],
                            ),
                            SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.event_outlined, size: 20),
                                SizedBox(width: 8),
                                Expanded(
                                    child: Text(
                                        "{{data_vencimento}} → Data de vencimento da parcela")),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _buildMensagemCard(
                      tipo: TipoMensagemCobranca.antesVencimento,
                      titulo: "Antes do vencimento",
                      subtitulo: "Enviada 1 dia antes do vencimento da parcela",
                    ),
                    _buildMensagemCard(
                      tipo: TipoMensagemCobranca.diaVencimento,
                      titulo: "No dia do vencimento",
                      subtitulo: "Enviada na data de vencimento",
                    ),
                    _buildMensagemCard(
                      tipo: TipoMensagemCobranca.aposVencimento,
                      titulo: "Após o vencimento",
                      subtitulo: "Enviada 1 dia após vencimento",
                    ),
                    _buildMensagemCard(
                      tipo: TipoMensagemCobranca.emprestimoQuitado,
                      titulo: "Empréstimo quitado",
                      subtitulo: "Enviada ao quitar o empréstimo",
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        empresaPodeUsarWhatsapp()
                            ? OutlinedButton.icon(
                                onPressed: _restaurarPadroes,
                                icon: const Icon(Icons.restore),
                                label: const Text("Restaurar Padrões"),
                              )
                            : const SizedBox.shrink(),
                        const SizedBox(width: 10),
                        Expanded(
                          child: CustomButton(
                            text: "Salvar",
                            enabled: empresaPodeUsarWhatsapp(),
                            onPressed: _salvarMensagens,
                            backgroundColor:
                                Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
