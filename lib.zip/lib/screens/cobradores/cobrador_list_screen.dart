import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/screens/cobradores/cobrador_create_screen.dart';
import 'package:emprestimos_app/screens/cobradores/cobrador_detail_screen.dart';
import 'package:emprestimos_app/widgets/custom_floating_action_button.dart';
import 'package:emprestimos_app/widgets/list_cobradores_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/providers/cobrador_provider.dart';

class CobradorListScreen extends StatefulWidget {
  const CobradorListScreen({super.key});

  @override
  State<CobradorListScreen> createState() => _CobradorListScreenState();
}

class _CobradorListScreenState extends State<CobradorListScreen> {
  String _searchQuery = "";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    Future.microtask(() async {
      await Provider.of<CobradorProvider>(context, listen: false)
          .listarCobradores()
          .then((_) {
        setState(() {
          _isLoading = false;
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cobradores')),
      body: Consumer<CobradorProvider>(
        builder: (context, provider, child) {
          return Column(
            children: [
              _buildSearchBar(),
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : RefreshIndicator(
                        onRefresh: () async {
                          setState(() => _isLoading = true);
                          await provider.listarCobradores();
                          setState(() => _isLoading = false);
                        },
                        child: ListaCobradoresWidget(
                          cobradores: provider.cobradores,
                          searchQuery: _searchQuery,
                        ),
                      ),
              )
            ],
          );
        },
      ),
      floatingActionButton: CustomFloatingActionButton(
        heroTag: "novo_cobrador_fab",
        onPressed: () {
          final result = Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CobradorFormScreen()),
          );

          result.then((value) {
            if (value != null && value is bool && value) {
              setState(() => _isLoading = true);
              Provider.of<CobradorProvider>(context, listen: false)
                  .listarCobradores();
              setState(() => _isLoading = false);
            }
          });
        },
        icon: Icons.add,
        label: "Novo Cobrador",
        backgroundColor: Theme.of(context).primaryColor,
      ),
    );
  }

  /// 🔹 Cabeçalho da Tela com Total de Cobradores
  Widget _buildHeader(BuildContext context, CobradorProvider provider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.group, color: Colors.white, size: 30),
                const SizedBox(width: 10),
                Text(
                  "Cobradores",
                  style: AppTheme.titleStyle.copyWith(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  "Total: ${provider.cobradores.length}",
                  style: const TextStyle(color: Colors.white70, fontSize: 16),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: TextField(
        decoration: InputDecoration(
          hintText: "Pesquisar cobrador...",
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(vertical: 10),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
        onChanged: (query) {
          setState(() {
            _searchQuery = query;
          });
        },
      ),
    );
  }

  /// 🔹 Ícone dinâmico no Trailing baseado no Status do Cobrador
  Widget _buildTrailingIcon(String status) {
    IconData icon;
    Color color;

    switch (status.toUpperCase()) {
      case "ATIVO":
        icon = Icons.check_circle;
        color = Colors.green;
        break;
      case "INATIVO":
        icon = Icons.cancel;
        color = Colors.red;
        break;
      default:
        icon = Icons.help_outline;
        color = Colors.grey;
        break;
    }

    return Icon(icon, color: color, size: 26);
  }
}
