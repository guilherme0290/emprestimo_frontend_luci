import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/models/cobrador.dart';
import 'package:emprestimos_app/models/emprestimo.dart';
import 'package:emprestimos_app/models/resumo_cobrador.dart';
import 'package:emprestimos_app/providers/emprestimo_provider.dart';
import 'package:emprestimos_app/screens/cobradores/cobrador_create_screen.dart';
import 'package:emprestimos_app/widgets/indicador_resumo_widget.dart';
import 'package:emprestimos_app/widgets/list_emprestimo_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DetalheCobradorScreen extends StatefulWidget {
  final Cobrador cobrador;

  const DetalheCobradorScreen({super.key, required this.cobrador});

  @override
  State<DetalheCobradorScreen> createState() => _DetalheCobradorScreenState();
}

class _DetalheCobradorScreenState extends State<DetalheCobradorScreen> {
  bool _isLoading = true;
  Cobrador? _cobradorCompleto;
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final provider = Provider.of<EmprestimoProvider>(context, listen: false);

      await Future.wait([provider.buscarAllEmprestimos(widget.cobrador)]);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<EmprestimoProvider>(context);
    final emprestimos = provider.emprestimos;

    return Scaffold(
      body: Column(
        children: [
          _buildCobradorResumoHeader(widget.cobrador),
          const Divider(height: 1),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: provider.isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : emprestimos.isNotEmpty
                      ? ListaEmprestimosWidget(
                          emprestimos: emprestimos,
                          exibirNomeCliente: true,
                        )
                      : Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                'assets/img/cliente_sem_emprestimo.png',
                                width: 120,
                                height: 120,
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                "Nenhum empréstimo encontrado para este cobrador!",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                  color: Color(0xFF9E9E9E),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCobradorResumoHeader(Cobrador cobrador) {
    final resumo = cobrador.resumoCobradorDTO;

    final capitalInvestido = resumo?.capitalInvestido ?? 0;
    final totalReceber = resumo?.totalReceber ?? 0;
    final adimplencia = resumo?.adimplentes.toInt() ?? 0;
    final inadimplencia = resumo?.inadimplentes.toInt() ?? 0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 Cabeçalho com botão voltar e nome
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back,
                      color: Colors.white, size: 28),
                  onPressed: () => Navigator.pop(context),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Resumo do Cobrador",
                        style: AppTheme.titleStyle.copyWith(
                          color: Colors.white70,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "${cobrador.id}-${cobrador.nome}",
                        style: AppTheme.titleStyle.copyWith(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.person_search,
                      color: Colors.white, size: 28),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => CobradorFormScreen(cobrador: cobrador),
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),

            // 🔹 Itens em Wrap com espaçamento
            Wrap(
              spacing: 20,
              runSpacing: 20,
              alignment: WrapAlignment.center,
              children: [
                _buildInfoItem(Icons.attach_money, "Capital Investido",
                    Util.formatarMoeda(capitalInvestido), ""),
                _buildInfoItem(Icons.trending_up, "Total em Aberto",
                    Util.formatarMoeda(totalReceber), ""),
                IndicadorResumoWidget(
                  titulo: "Inadimplentes",
                  valor: "${inadimplencia.toStringAsFixed(1)}%",
                  cor: Colors.red,
                  icone: Icons.warning_amber_rounded,
                ),
                IndicadorResumoWidget(
                  titulo: "Adimplentes",
                  valor: "${adimplencia.toStringAsFixed(1)}%",
                  cor: Colors.green,
                  icone: Icons.check_circle,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(
    IconData icon,
    String label,
    String value,
    String descricao,
  ) {
    return Container(
      width: 130, // Largura mínima para evitar quebras indesejadas
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white70, size: 26),
          const SizedBox(height: 6),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 12),
              textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
