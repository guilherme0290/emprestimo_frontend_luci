import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/cobrador.dart';
import '../../providers/cobrador_provider.dart';
import '../../widgets/custom_button.dart';
import '../../core/theme/theme.dart';

class TrocarCobradorScreen extends StatefulWidget {
  final int cobradorDesligadoId;

  const TrocarCobradorScreen({required this.cobradorDesligadoId, Key? key})
      : super(key: key);

  @override
  State<TrocarCobradorScreen> createState() => _TrocarCobradorScreenState();
}

class _TrocarCobradorScreenState extends State<TrocarCobradorScreen> {
  int? _cobradorSelecionadoId;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    if (!mounted) return;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      Provider.of<CobradorProvider>(context, listen: false).listarCobradores();
    });
  }

  void _confirmarTroca() async {
    if (_cobradorSelecionadoId == null) return;

    setState(() => _isSubmitting = true);

    final provider = Provider.of<CobradorProvider>(context, listen: false);
    final sucesso = await provider.transferirEmprestimos(
      cobradorDesligadoId: widget.cobradorDesligadoId,
      novoCobradorId: _cobradorSelecionadoId!,
    );

    if (sucesso) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Transferência concluída com sucesso!"),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(provider.errorMessage ?? "Erro na transferência."),
          backgroundColor: Colors.red,
        ),
      );
    }

    setState(() => _isSubmitting = false);
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<CobradorProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Transferir Empréstimos "),
      ),
      body: AppBackground(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Selecione o novo cobrador para receber os empréstimos e/ou clientes:",
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<int>(
                value: _cobradorSelecionadoId,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: "Novo Cobrador",
                  border: OutlineInputBorder(),
                ),
                items: provider.cobradores
                    .where((c) => c.id != widget.cobradorDesligadoId)
                    .map((c) => DropdownMenuItem(
                          value: c.id,
                          child: Text(c.nome),
                        ))
                    .toList(),
                onChanged: (novoId) {
                  setState(() {
                    _cobradorSelecionadoId = novoId;
                  });
                },
                validator: (value) =>
                    value == null ? "Escolha um cobrador" : null,
              ),
              const SizedBox(height: 30),
              _isSubmitting
                  ? const Center(child: CircularProgressIndicator())
                  : CustomButton(
                      text: "Confirmar Transferência",
                      onPressed: _confirmarTroca,
                      backgroundColor: AppTheme.primaryColor,
                    )
            ],
          ),
        ),
      ),
    );
  }
}
