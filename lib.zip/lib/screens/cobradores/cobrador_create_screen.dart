import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/models/cidade.dart';
import 'package:emprestimos_app/models/cobrador.dart';
import 'package:emprestimos_app/providers/cliente_provider.dart';
import 'package:emprestimos_app/providers/cobrador_provider.dart';
import 'package:emprestimos_app/screens/cobradores/cobrador_inativacao.dart';
import 'package:emprestimos_app/widgets/background_screens_widget.dart';
import 'package:emprestimos_app/widgets/dialog_widget.dart';
import 'package:emprestimos_app/widgets/input_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import '../../widgets/custom_button.dart';
import '../../core/theme/theme.dart';

class CobradorFormScreen extends StatefulWidget {
  final Cobrador? cobrador;

  const CobradorFormScreen({this.cobrador, Key? key}) : super(key: key);

  @override
  _CobradorFormScreenState createState() => _CobradorFormScreenState();
}

class _CobradorFormScreenState extends State<CobradorFormScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _hasFocus = false;
  bool _statusAtivo = true;

  final TextEditingController nomeController = TextEditingController();
  final TextEditingController cpfController = TextEditingController();
  final TextEditingController telefoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController ruaController = TextEditingController();
  final TextEditingController bairroController = TextEditingController();
  final TextEditingController cepController = TextEditingController();
  final TextEditingController complementoController = TextEditingController();
  final TextEditingController numeroController = TextEditingController();
  final TextEditingController senhaController = TextEditingController();

  final cpfFormatter = MaskTextInputFormatter(
    mask: '###.###.###-##',
    filter: {"#": RegExp(r'[0-9]')},
  );

  final cepFormatter = MaskTextInputFormatter(
    mask: '#####-###',
    filter: {"#": RegExp(r'[0-9]')},
  );

  final telefoneFormatter = MaskTextInputFormatter(
    mask: '(##) #####-####',
    filter: {"#": RegExp(r'[0-9]')},
  );

  bool isLoading = false;
  int? _cidadeSelecionada;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<ClienteProvider>(context, listen: false).carregarCidades();
    });

    if (widget.cobrador != null) {
      nomeController.text = widget.cobrador?.nome ?? "";
      cpfController.text = widget.cobrador?.cpf ?? "";
      telefoneController.text = widget.cobrador?.telefone ?? "";
      emailController.text = widget.cobrador?.email ?? "";
      ruaController.text = widget.cobrador?.rua ?? "";
      bairroController.text = widget.cobrador?.bairro ?? "";
      cepController.text = widget.cobrador?.cep ?? "";
      complementoController.text = widget.cobrador?.complemento ?? "";
      numeroController.text = widget.cobrador?.numero ?? "";
      _cidadeSelecionada = widget.cobrador?.cidadeId;
      _statusAtivo = widget.cobrador?.status == "ATIVO";
    }
  }

  void _salvarCobrador() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = Provider.of<CobradorProvider>(context, listen: false);

    Cobrador novoCobrador = Cobrador(
      id: widget.cobrador?.id,
      cpf: Util.removerMascara(cpfController.text),
      nome: nomeController.text,
      rua: ruaController.text,
      telefone: Util.removerMascara(telefoneController.text),
      email: emailController.text,
      bairro: bairroController.text,
      cep: Util.removerMascara(cepController.text),
      complemento: complementoController.text,
      numero: numeroController.text,
      cidadeId: _cidadeSelecionada,
      status: _statusAtivo ? "ATIVO" : "INATIVO",
    );

    bool sucessCreate = false;
    bool sucessUpdate = false;
    if (widget.cobrador == null) {
      sucessCreate = await provider.criarCobrador(novoCobrador);
    } else {
      sucessUpdate = await provider.atualizarCobrador(novoCobrador);
    }

    if (!mounted) return;
    if (sucessCreate) {
      MyAwesomeDialog(
              dialogType: DialogType.success,
              context: context,
              btnOkText: 'Ok',
              onOkPressed: () {
                Navigator.pop(context, true);
              },
              title: "Cobrador criado com sucesso! ",
              message:
                  'Solicite para que o cobrador verifique o e-mail informado para cadastrar uma senha.')
          .show();
    } else if (sucessUpdate) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(provider.sucessMessage!),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } else {
      MyAwesomeDialog(
              dialogType: DialogType.error,
              context: context,
              btnOkText: 'Ok',
              title: "Erro ao criar/atualizar cobrador  !",
              message: provider.errorMessage!)
          .show();
    }
  }

  void _alternarStatus(bool novoStatus) async {
    if (!novoStatus) {
      final provider = Provider.of<CobradorProvider>(context, listen: false);
      final resultado =
          await provider.consultarVinculosCobrador(widget.cobrador!.id!);

      if (resultado != null) {
        AwesomeDialog(
          context: context,
          dialogType: DialogType.question,
          animType: AnimType.scale,
          title: 'Inativar Cobrador?',
          desc:
              'Este cobrador possui ${resultado.emprestimos} empréstimos em andamento e ${resultado.clientes} clientes ativos.\nO que deseja fazer?',
          btnOkText: "Transferir",
          btnCancelText: "Apenas Inativar",
          btnOkOnPress: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => TrocarCobradorScreen(
                      cobradorDesligadoId: widget.cobrador!.id!)),
            );
          },
          btnCancelOnPress: () {
            _salvarCobrador();
          },
        ).show();
      }
    }
    setState(() {
      _statusAtivo = novoStatus;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
              widget.cobrador == null ? "Novo Cobrador" : "Editar Cobrador"),
        ),
        body: Consumer<CobradorProvider>(builder: (context, provider, child) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: AppBackground(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildSectionTitle("Informações Pessoais"),
                      SwitchListTile(
                        title: const Text("Status do Cobrador"),
                        subtitle: Text(_statusAtivo ? "Ativo" : "Inativo"),
                        value: _statusAtivo,
                        onChanged: _alternarStatus,
                        activeColor: Colors.green,
                        inactiveThumbColor: Colors.red,
                      ),
                      const SizedBox(height: 10),
                      InputCustomizado(
                          controller: nomeController,
                          labelText: "Nome Completo",
                          leadingIcon: const Icon(Icons.person,
                              color: AppTheme.primaryColor),
                          validator: (value) =>
                              value!.isEmpty ? "Campo obrigatório" : null),
                      const SizedBox(height: 10),
                      InputCustomizado(
                        controller: cpfController,
                        labelText: "CPF",
                        type: TextInputType.number,
                        leadingIcon: const Icon(Icons.credit_card,
                            color: AppTheme.primaryColor),
                        inputFormatters: [cpfFormatter],
                        validator: (value) =>
                            Util.isCpfValid(cpfController.text),
                      ),
                      const SizedBox(height: 10),
                      InputCustomizado(
                          controller: telefoneController,
                          labelText: "Telefone",
                          type: TextInputType.number,
                          leadingIcon: const Icon(Icons.phone,
                              color: AppTheme.primaryColor),
                          inputFormatters: [telefoneFormatter],
                          validator: (value) =>
                              value!.isEmpty ? "Campo obrigatório" : null),
                      const SizedBox(height: 10),
                      InputCustomizado(
                          controller: emailController,
                          labelText: "E-mail",
                          type: TextInputType.emailAddress,
                          leadingIcon: const Icon(Icons.email,
                              color: AppTheme.primaryColor),
                          validator: (value) =>
                              Util.isEmailValid(emailController.text)),
                      const SizedBox(height: 16),
                      provider.isLoading
                          ? const CircularProgressIndicator()
                          : CustomButton(
                              text: "Salvar Cobrador",
                              onPressed: _salvarCobrador,
                              backgroundColor:
                                  Theme.of(context).colorScheme.primary,
                            ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }));
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: AppTheme.titleStyle
            .copyWith(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}
