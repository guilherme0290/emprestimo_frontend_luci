import 'package:emprestimos_app/models/planos.dart';
import 'package:emprestimos_app/screens/cobradores/cobrador_list_screen.dart';
import 'package:emprestimos_app/screens/config/config_screen.dart';
import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/screens/home/home_cobrador_screen.dart';
import 'package:flutter/material.dart';
import 'home_empresa_screen.dart';
import '../clientes/cliente_list_screen.dart';

class MainScreen extends StatefulWidget {
  final String role; // Pode ser "EMPRESA" ou "COBRADOR"
  final Plano? plano;

  const MainScreen({required this.role, this.plano, Key? key})
      : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with TickerProviderStateMixin {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final bool isCobrador = widget.role == "COBRADOR";
    final bool isPlanoPremium =
        widget.plano?.nome?.toUpperCase().contains("PREMIUM") ?? false;

    // Define menus e telas dinamicamente
    final List<BottomNavigationBarItem> menuItems = [
      const BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
      const BottomNavigationBarItem(
          icon: Icon(Icons.people), label: "Clientes"),
      if (!isCobrador && isPlanoPremium)
        const BottomNavigationBarItem(
            icon: Icon(Icons.supervisor_account), label: "Cobradores"),
      const BottomNavigationBarItem(
          icon: Icon(Icons.settings), label: "Config."),
    ];

    final List<Widget> telas = [
      isCobrador ? const HomeCobradorScreen() : const HomeEmpresaScreen(),
      const ClienteListScreen(),
      if (!isCobrador && isPlanoPremium) const CobradorListScreen(),
      const ConfigScreen(),
    ];

    final int atualIndex =
        _selectedIndex >= telas.length ? telas.length - 1 : _selectedIndex;

    return buildScaffold(menuItems, telas, atualIndex);
  }

  Widget buildScaffold(
      List<BottomNavigationBarItem> items, List<Widget> telas, int index) {
    return Scaffold(
      body: telas[index],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 6,
              offset: const Offset(0, -3),
            ),
          ],
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          child: BottomNavigationBar(
            items: items,
            currentIndex: index,
            selectedItemColor: AppTheme.primaryColor,
            unselectedItemColor: Colors.grey.shade500,
            backgroundColor: Colors.white,
            elevation: 10,
            iconSize: 28,
            type: BottomNavigationBarType.fixed,
            selectedFontSize: 14,
            unselectedFontSize: 12,
            showUnselectedLabels: true,
            onTap: (i) {
              setState(() {
                _selectedIndex = i;
              });
            },
          ),
        ),
      ),
    );
  }
}
