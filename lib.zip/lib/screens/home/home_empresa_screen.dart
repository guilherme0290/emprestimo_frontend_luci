import 'package:emprestimos_app/providers/empresa_provider.dart';
import 'package:emprestimos_app/providers/emprestimo_provider.dart';
import 'package:emprestimos_app/providers/notificacoes_provider.dart';
import 'package:emprestimos_app/providers/parametros_provider.dart';
import 'package:emprestimos_app/providers/planos_provider.dart';
import 'package:emprestimos_app/widgets/banner_aviso_ativacao_widget.dart';
import 'package:emprestimos_app/widgets/botoes_acoes_rapidas.dart';
import 'package:emprestimos_app/widgets/bottomsheet_ativacao_plano.dart';
import 'package:emprestimos_app/widgets/parcelas_relevantes.dart';
import 'package:emprestimos_app/widgets/resumo_painel_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeEmpresaScreen extends StatefulWidget {
  const HomeEmpresaScreen({super.key});

  @override
  State<HomeEmpresaScreen> createState() => _HomeEmpresaScreenState();
}

class _HomeEmpresaScreenState extends State<HomeEmpresaScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return; // Verifica se ainda está na árvore de widgets

      final provider = Provider.of<EmprestimoProvider>(context, listen: false);
      final parametroProvider =
          Provider.of<ParametroProvider>(context, listen: false);

      final empresaProvider =
          Provider.of<EmpresaProvider>(context, listen: false);

      try {
        await Future.wait([
          provider.buscarParcelasRelevantes(),
          provider.buscarResumoEmpresa(),
          empresaProvider.buscarEmpresaById(null)
        ]);
        parametroProvider.buscarParametrosEmpresa();

        if (mounted) {
          setState(() {}); // Atualiza a UI apenas se ainda estiver montado
        }
      } catch (e) {
        debugPrint('Erro ao buscar dados: $e');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<EmprestimoProvider>(context);
    final empresaProvider =
        Provider.of<EmpresaProvider>(context, listen: false);
    final nomeUsuario = empresaProvider.getNomeEmpresa();

    final notificacaoProvider = Provider.of<NotificacaoProvider>(context);

    return Scaffold(
        body: Column(
      children: [
        ResumoPainelWidget(
          isEmpresa: true,
          capitalInvestido: provider.resumoEmpresa?.capitalInvestido ?? 0.0,
          totalReceber: provider.resumoEmpresa?.totalReceber ?? 0.0,
          inadimplentes: provider.resumoEmpresa?.inadimplentes ?? 0,
          adimplentes: provider.resumoEmpresa?.adimplentes ?? 0,
          esconderValores: provider.esconderValores,
          onToggleEsconderValores: provider.toggleEsconderValores,
          nomeUsuario: nomeUsuario,
          notificacoesNaoVisualizadas:
              notificacaoProvider.notificacoesNaoVisualizadas,
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BtnAcoesRapidas(),
                const SizedBox(height: 8),
                if (empresaProvider.empresa != null &&
                    !empresaProvider.empresa!.planoAtivo)
                  BannerAvisoAtivacao(
                    createdAt: empresaProvider.empresa!.createdAt!,
                    onAtivarPlano: () {
                      showBottomSheetAtivacao(
                          context: context,
                          plano: empresaProvider.empresa!.plano,
                          buscarPlanoSelecionado: null);
                    },
                  ),

                _buildTituloSecao("Parcelas Relevantes"),
                provider.isLoading
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 24.0),
                          child: CircularProgressIndicator(),
                        ),
                      )
                    : ParcelasResumoCard(
                        fetchData: provider.buscarParcelasRelevantes,
                        parcelas: provider.parcelas,
                        isLoading: false,
                      ),
                const SizedBox(height: 20),
                _buildTituloSecao("Lucratividade"),
                //  _buildGraficoLucratividade(provider),
              ],
            ),
          ),
        ),
      ],
    ));
  }

  /// 🔹 Título das Seções
  Widget _buildTituloSecao(String titulo) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        titulo,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.black54, // Cor cinza suave
        ),
      ),
    );
  }
}
