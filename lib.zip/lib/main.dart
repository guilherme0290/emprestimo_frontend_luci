import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/firebase_options.dart';
import 'package:emprestimos_app/providers/cliente_provider.dart';
import 'package:emprestimos_app/providers/cobrador_provider.dart';
import 'package:emprestimos_app/providers/cobranca_provider.dart';
import 'package:emprestimos_app/providers/compra_provider.dart';
import 'package:emprestimos_app/providers/emprestimo_provider.dart';
import 'package:emprestimos_app/providers/mensagens_cobranca_provider.dart';
import 'package:emprestimos_app/providers/notificacoes_provider.dart';
import 'package:emprestimos_app/providers/parametros_provider.dart';
import 'package:emprestimos_app/providers/planos_provider.dart';
import 'package:emprestimos_app/providers/score_provider.dart';
import 'package:emprestimos_app/providers/usuario_provider.dart';
import 'package:emprestimos_app/screens/auth/auth_wrapper.dart';
import 'package:emprestimos_app/screens/auth/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:emprestimos_app/providers/empresa_provider.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'providers/auth_provider.dart';
import 'package:emprestimos_app/core/navigation_service.dart';

// 🚀 Configuração para Notificações Firebase
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print("🔔 Mensagem recebida em segundo plano: ${message.messageId}");
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await initializeDateFormatting('pt_BR', null);

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        //
        ChangeNotifierProxyProvider<AuthProvider, UsuarioProvider>(
          create: (context) => UsuarioProvider(),
          update: (context, authProvider, previous) =>
              previous!..atualizarUsuario(authProvider),
        ),

        ChangeNotifierProxyProvider<AuthProvider, EmpresaProvider>(
          create: (context) => EmpresaProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

        ChangeNotifierProxyProvider<AuthProvider, EmprestimoProvider>(
          create: (context) => EmprestimoProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

        ChangeNotifierProxyProvider<AuthProvider, ClienteProvider>(
          create: (context) => ClienteProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

        ChangeNotifierProxyProvider<AuthProvider, CobradorProvider>(
          create: (context) => CobradorProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

// Opcional: manter se quiser evitar recarregamento dos parâmetros
        ChangeNotifierProxyProvider<AuthProvider, ParametroProvider>(
          create: (context) => ParametroProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

// Opcional: manter se você guarda notificações já carregadas
        ChangeNotifierProxyProvider<AuthProvider, NotificacaoProvider>(
          create: (context) =>
              NotificacaoProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              previous!..atualizarAuthProvider(authProvider),
        ),

        ChangeNotifierProxyProvider<AuthProvider, MensagemCobrancaProvider>(
          create: (context) =>
              MensagemCobrancaProvider(context.read<AuthProvider>()),
          update: (context, authProvider, previous) =>
              MensagemCobrancaProvider(authProvider),
        ),
        ChangeNotifierProxyProvider<EmpresaProvider, CompraProvider>(
          create: (_) => CompraProvider(),
          update: (_, empresaProvider, compraProvider) =>
              compraProvider!..setEmpresaProvider(empresaProvider),
        ),

        ChangeNotifierProvider(create: (_) => ClienteScoreProvider()),
        ChangeNotifierProvider(create: (_) => CobrancaProvider()),
        ChangeNotifierProvider(create: (_) => PlanoProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'App de Empréstimos',
        theme: AppTheme.lightTheme,
        navigatorKey: navigatorKey,
        home: const AuthWrapper(),
        routes: {
          '/login': (context) => LoginScreen(),
        },
      ),
    );
  }
}
