class ResumoEmprestimosCliente {
  final int totalEmprestimos;
  final double valorTotalEmprestado;
  final double saldoDevedor;
  final int parcelasAtrasadas;

  ResumoEmprestimosCliente({
    required this.totalEmprestimos,
    required this.valorTotalEmprestado,
    required this.saldoDevedor,
    required this.parcelasAtrasadas,
  });

  factory ResumoEmprestimosCliente.fromJson(Map<String, dynamic> json) {
    return ResumoEmprestimosCliente(
      totalEmprestimos: json['totalEmprestimos'],
      valorTotalEmprestado: json['valorTotalEmprestado'].toDouble(),
      saldoDevedor: json['saldoDevedor'].toDouble(),
      parcelasAtrasadas: json['parcelasAtrasadas'],
    );
  }
}
