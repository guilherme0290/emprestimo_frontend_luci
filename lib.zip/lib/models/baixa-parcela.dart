class BaixaParcelaDTO {
  int? id;
  double valor;
  String? tipoBaixa; // "JUROS", "PARCIAL", "TOTAL", "QUITADA"
  String? dataPagamento; // "2025-03-03T23:57:47.921016"
  int? cobradorId;
  String? cobradorNome;
  int parcelaId;
  String? createdAt;

  BaixaParcelaDTO({
    this.id,
    required this.valor,
    this.tipoBaixa,
    this.dataPagamento,
    this.cobradorId,
    this.cobradorNome,
    required this.parcelaId,
    this.createdAt,
  });

  factory BaixaParcelaDTO.fromJson(Map<String, dynamic> json) {
    return BaixaParcelaDTO(
      id: json['id'] as int,
      valor: (json['valor'] as num).toDouble(),
      tipoBaixa: json['tipoBaixa'] as String,
      dataPagamento: json['dataPagamento'] ?? '',
      cobradorId: json['cobradorId'] as int?,
      cobradorNome: json['cobradorNome'],
      parcelaId: json['parcelaId'] as int,
      createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "valor": valor,
      "tipoBaixa": tipoBaixa,
      "dataPagamento": dataPagamento,
      "cobradorId": cobradorId,
      "parcelaId": parcelaId,
      "createdAt": createdAt
    };
  }
}
