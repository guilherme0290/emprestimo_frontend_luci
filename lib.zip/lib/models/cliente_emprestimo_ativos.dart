class ClientesEmprestimosAtivos {
  final int emprestimos;
  final int clientes;

  ClientesEmprestimosAtivos({
    required this.emprestimos,
    required this.clientes,
  });

  // Construtor a partir de JSON
  factory ClientesEmprestimosAtivos.fromJson(Map<String, dynamic> json) {
    return ClientesEmprestimosAtivos(
      emprestimos: json['emprestimos'] as int,
      clientes: json['clientes'] as int,
    );
  }
}
