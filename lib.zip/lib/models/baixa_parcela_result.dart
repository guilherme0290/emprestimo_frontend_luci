class BaixaParcelaResult {
  final bool sucesso;
  final String? mensagemErro;

  BaixaParcelaResult({required this.sucesso, this.mensagemErro});
}
