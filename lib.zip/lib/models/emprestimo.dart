import 'package:emprestimos_app/models/cliente.dart';
import 'package:emprestimos_app/models/parcela.dart';
import 'package:emprestimos_app/models/penhora.dart';

class EmprestimoDTO {
  final int id;
  final double valor;
  final double juros;
  final String tipoPagamento;
  final String dataPrimeiroVencimento;
  final String dataUltimoVencimento;
  final String statusEmprestimo;
  final int? empresaId;
  final String? cobradorNome;
  final Cliente cliente;
  final PenhoraDTO? penhora;
  final List<ParcelaDTO> parcelas;

  EmprestimoDTO(
      {required this.id,
      required this.valor,
      required this.juros,
      required this.tipoPagamento,
      required this.dataPrimeiroVencimento,
      required this.dataUltimoVencimento,
      required this.statusEmprestimo,
      this.empresaId,
      required this.cliente,
      this.cobradorNome,
      required this.parcelas,
      this.penhora});

  factory EmprestimoDTO.fromJson(Map<String, dynamic> json) {
    return EmprestimoDTO(
      id: json['id'] as int,
      valor: (json['valor'] as num).toDouble(),
      juros: (json['juros'] as num).toDouble(),
      tipoPagamento: json['tipoPagamento'] as String,
      dataPrimeiroVencimento: json['dataPrimeiroVencimento'] ?? '',
      dataUltimoVencimento: json['dataUltimoVencimento'] ?? '',
      statusEmprestimo: json['statusEmprestimo'] ?? '',
      empresaId: json['empresaId'] as int,
      cliente: Cliente.fromJson(json['cliente']),
      cobradorNome: json['cobradorNome'] ?? '',
      parcelas: (json['parcelas'] as List<dynamic>)
          .map((p) => ParcelaDTO.fromJson(p as Map<String, dynamic>))
          .toList(),
      penhora: json['penhora'] is Map<String, dynamic>
          ? PenhoraDTO.fromJson(json['penhora'])
          : null,
    );
  }

  // Método copyWith para atualizar um único campo sem modificar os demais
  EmprestimoDTO copyWith({List<ParcelaDTO>? parcelas}) {
    return EmprestimoDTO(
      id: id,
      valor: valor,
      juros: juros,
      tipoPagamento: tipoPagamento,
      dataPrimeiroVencimento: dataPrimeiroVencimento,
      dataUltimoVencimento: dataUltimoVencimento,
      statusEmprestimo: statusEmprestimo,
      empresaId: empresaId,
      cliente: cliente,
      parcelas: parcelas ?? this.parcelas,
    );
  }
}
