import 'package:emprestimos_app/models/cliente.dart';
import 'package:emprestimos_app/models/penhora.dart';

class NovoEmprestimoDTO {
  double valor;
  double juros;
  int numeroParcelas;
  String tipoPagamento;
  Cliente? cliente;
  int? cobradorId;
  PenhoraDTO? penhora;

  NovoEmprestimoDTO(
      {required this.valor,
      required this.juros,
      required this.numeroParcelas,
      required this.tipoPagamento,
      this.cliente,
      this.cobradorId,
      this.penhora});

  Map<String, dynamic> toJson() {
    return {
      'valor': valor,
      'juros': juros,
      'numeroParcelas': numeroParcelas,
      'tipoPagamento': tipoPagamento,
      'clienteId': cliente?.id,
      'cobradorId': cobradorId,
      'penhoraDTO': penhora
    };
  }
}
