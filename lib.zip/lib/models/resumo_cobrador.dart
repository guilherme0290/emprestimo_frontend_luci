class ResumoTotalizadoresEmprestimo {
  final double capitalInvestido;
  final double totalReceber;
  final double totalRecebidos;
  final double inadimplentes;
  final double adimplentes;

  ResumoTotalizadoresEmprestimo({
    required this.capitalInvestido,
    required this.totalReceber,
    required this.totalRecebidos,
    required this.inadimplentes,
    required this.adimplentes,
  });

  factory ResumoTotalizadoresEmprestimo.fromJson(Map<String, dynamic> json) {
    return ResumoTotalizadoresEmprestimo(
      capitalInvestido: (json['capitalInvestido'] ?? 0).toDouble(),
      totalReceber: (json['totalReceber'] ?? 0).toDouble(),
      totalRecebidos: (json['totalRecebidos'] ?? 0).toDouble(),
      inadimplentes: (json['inadimplentes'] ?? 0).toDouble(),
      adimplentes: (json['adimplentes'] ?? 0).toDouble(),
    );
  }
}
