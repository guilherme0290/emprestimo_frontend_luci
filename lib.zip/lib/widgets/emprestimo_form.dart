import 'package:emprestimos_app/core/util.dart';
import 'package:emprestimos_app/models/parametro.dart';
import 'package:emprestimos_app/models/penhora.dart';
import 'package:emprestimos_app/widgets/custom_button.dart';
import 'package:emprestimos_app/widgets/custom_swithtile.dart';
import 'package:emprestimos_app/widgets/currency_formatter.dart';
import 'package:emprestimos_app/widgets/input_field.dart';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class EmprestimoForm extends StatefulWidget {
  final Function(double, double, int, String, PenhoraDTO?) onSubmit;
  final bool isSimulation;
  final List<Parametro> parametrosCliente;
  final List<Parametro> parametrosEmpresa;

  const EmprestimoForm({
    Key? key,
    required this.onSubmit,
    this.isSimulation = false,
    required this.parametrosCliente,
    required this.parametrosEmpresa,
  }) : super(key: key);

  @override
  _EmprestimoFormState createState() => _EmprestimoFormState();
}

class _EmprestimoFormState extends State<EmprestimoForm> {
  final _formKey = GlobalKey<FormState>();
  final _valorController = TextEditingController();
  final _jurosController = TextEditingController();
  final _numeroParcelasController = TextEditingController();
  String _tipoPagamentoSelecionado = "MENSAL";

  bool _showNumeroParcelasField = false;
  bool _hasPenhora = false;

  final _penhoraDescricaoController = TextEditingController();
  final _penhoraValorEstimadoController = TextEditingController();
  final _jurosMask =
      MaskTextInputFormatter(mask: "##%", filter: {"#": RegExp(r'[0-9]')});

  bool isLimiteCreditoUltrapassado = false;
  String? mensagemErroCredito;

  @override
  void initState() {
    super.initState();
    _showNumeroParcelasField = _tipoPagamentoSelecionado != "MENSAL";
    if (!_showNumeroParcelasField) {
      _numeroParcelasController.text = "1";
    }
    _setarJurosPadrao();
    _valorController.addListener(_verificarLimiteCredito);
  }

  void _setarJurosPadrao() {
    final clienteParam = widget.parametrosCliente.firstWhere(
      (p) => p.chave == 'JUROS_PADRAO_CLIENTE',
      orElse: () => Parametro(
          valor: '', chave: '', id: 0, referenciaId: 0, tipoReferencia: ''),
    );
    final empresaParam = widget.parametrosEmpresa.firstWhere(
      (p) => p.chave == 'JUROS_PADRAO',
      orElse: () => Parametro(
          valor: '', chave: '', id: 0, referenciaId: 0, tipoReferencia: ''),
    );

    final valor =
        (clienteParam.valor.isNotEmpty && clienteParam.valor != "0") == true
            ? clienteParam.valor
            : empresaParam.valor;

    final valorDouble = double.tryParse(valor.replaceAll(',', '.')) ?? 0;

    final valorInt = valorDouble.toInt();

    _jurosController.text = valorInt.toString();
  }

  void _verificarLimiteCredito() {
    if (!widget.isSimulation) {
      final valorDigitado = Util.removerMascaraValor(_valorController.text);
      final limite = _getLimiteCredito();

      if (limite > 0) {
        setState(() {
          isLimiteCreditoUltrapassado = valorDigitado > limite;
          mensagemErroCredito = isLimiteCreditoUltrapassado
              ? 'Limite de crédito excedido: ${Util.formatarMoeda(limite)}'
              : null;
        });
      }
    }
  }

  double _getLimiteCredito() {
    final clienteParam = widget.parametrosCliente.firstWhere(
      (p) => p.chave == 'LIMITE_CREDITO_CLIENTE',
      orElse: () => Parametro(
          valor: '', chave: '', id: 0, referenciaId: 0, tipoReferencia: ''),
    );
    final empresaParam = widget.parametrosEmpresa.firstWhere(
      (p) => p.chave == 'LIMITE_EMPRESTIMO',
      orElse: () => Parametro(
          valor: '', chave: '', id: 0, referenciaId: 0, tipoReferencia: ''),
    );

    final clienteValor = double.tryParse(clienteParam.valor);
    final empresaValor = double.tryParse(empresaParam.valor);

    double limiteCredito = 0;
    if (clienteValor != null && clienteValor > 0) {
      limiteCredito = clienteValor;
    } else if (empresaValor != null && empresaValor > 0) {
      limiteCredito = empresaValor;
    }
    return limiteCredito;
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final valor = Util.removerMascaraValor(_valorController.text);
      final juros = Util.removerMascaraValor(_jurosController.text);
      final parcelas = int.tryParse(_numeroParcelasController.text) ?? 1;
      final valorPenhora =
          Util.removerMascaraValor(_penhoraValorEstimadoController.text);

      final penhora = _hasPenhora
          ? PenhoraDTO(
              descricao: _penhoraDescricaoController.text,
              valorEstimado: valorPenhora,
            )
          : null;

      widget.onSubmit(
          valor, juros, parcelas, _tipoPagamentoSelecionado, penhora);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          _buildCardEmprestimo(),
          const SizedBox(height: 16),
          _buildCardPenhora(),
          const SizedBox(height: 16),
          CustomButton(
            text: widget.isSimulation ? "Simular" : "Próximo",
            onPressed: isLimiteCreditoUltrapassado ? null : _submitForm,
          )
        ],
      ),
    );
  }

  Widget _buildCardEmprestimo() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            InputCustomizado(
              controller: _valorController,
              labelText: 'Valor do Empréstimo',
              type: TextInputType.number,
              inputFormatters: [CurrencyFormatter()],
              validator: (value) => (value == null || value.isEmpty)
                  ? "Favor informar o valor do empréstimo!"
                  : null,
            ),
            if (mensagemErroCredito != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  mensagemErroCredito!,
                  style: TextStyle(color: Colors.red.shade700, fontSize: 12),
                ),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: InputCustomizado(
                    controller: _jurosController,
                    labelText: 'Juros (%)',
                    type: TextInputType.number,
                    inputFormatters: [_jurosMask],
                    validator: (value) => (value == null || value.isEmpty)
                        ? "Informe este campo"
                        : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _tipoPagamentoSelecionado,
                    items: const [
                      DropdownMenuItem(value: "MENSAL", child: Text("Mensal")),
                      DropdownMenuItem(
                          value: "SEMANAL", child: Text("Semanal")),
                      DropdownMenuItem(value: "DIARIO", child: Text("Diário")),
                    ],
                    onChanged: (String? newValue) {
                      setState(() {
                        _tipoPagamentoSelecionado = newValue ?? "MENSAL";
                        _showNumeroParcelasField =
                            _tipoPagamentoSelecionado != "MENSAL";
                        if (!_showNumeroParcelasField) {
                          _numeroParcelasController.text = "1";
                        }
                      });
                    },
                    decoration: InputDecoration(
                      labelText: "Tipo de Pagamento",
                      labelStyle: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                    ),
                    icon: Icon(Icons.arrow_drop_down,
                        color: Theme.of(context).primaryColor),
                    dropdownColor: Theme.of(context).scaffoldBackgroundColor,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_showNumeroParcelasField)
              InputCustomizado(
                controller: _numeroParcelasController,
                labelText: 'Número de parcelas',
                type: TextInputType.number,
                validator: (value) => (value == null || value.isEmpty)
                    ? "Favor informar o numero de parcelas!"
                    : null,
              )
          ],
        ),
      ),
    );
  }

  Widget _buildCardPenhora() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            CustomSwitchTile(
              title: "Incluir Penhora",
              value: _hasPenhora,
              onChanged: (value) => setState(() => _hasPenhora = value),
              icon: Icons.security,
              subtitle: "Habilite para incluir penhora no contrato.",
            ),
            if (_hasPenhora) _buildPenhoraFields(),
          ],
        ),
      ),
    );
  }

  Widget _buildPenhoraFields() {
    return Column(
      children: [
        InputCustomizado(
          controller: _penhoraDescricaoController,
          labelText: 'O que você está empenhorando?',
          validator: (value) => (value == null || value.isEmpty)
              ? "Favor informar um nome para o produto!"
              : null,
        ),
        const SizedBox(height: 12),
        InputCustomizado(
          controller: _penhoraValorEstimadoController,
          labelText: 'Está pegando por qual valor?',
          type: TextInputType.number,
          inputFormatters: [CurrencyFormatter()],
          validator: (value) => (value == null || value.isEmpty)
              ? "Favor informar valor para o produto!"
              : null,
        )
      ],
    );
  }
}
