import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:emprestimos_app/core/theme/theme.dart';
import 'package:emprestimos_app/models/planos.dart';

Future<void> showBottomSheetAtivacao({
  required BuildContext context,
  Plano? plano,
  Future<Plano?> Function()? buscarPlanoSelecionado,
}) async {
  final Plano? planoSelecionado = plano ??
      (buscarPlanoSelecionado != null ? await buscarPlanoSelecionado() : null);

  if (planoSelecionado == null ||
      planoSelecionado.productIdGooglePlay == null) {
    // Pode mostrar um alerta de erro aqui se quiser
    return;
  }

  showModalBottomSheet(
    context: context,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (_) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Ativação de Plano",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              "Para concluir o cadastro da sua empresa, é necessário ativar sua assinatura na Google Play.",
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () async {
                final productId = planoSelecionado!.productIdGooglePlay;
                final response = await InAppPurchase.instance
                    .queryProductDetails({productId!});
                final produto = response.productDetails.first;

                final param = PurchaseParam(productDetails: produto);
                await InAppPurchase.instance
                    .buyNonConsumable(purchaseParam: param);

                Navigator.pop(context);
              },
              icon: const Icon(Icons.play_circle_fill),
              label: const Text("Ativar assinatura"),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
                backgroundColor: AppTheme.primaryColor,
              ),
            ),
          ],
        ),
      );
    },
  );
}
