import 'package:emprestimos_app/core/dio_error_handler.dart';
import 'package:emprestimos_app/models/api_response.dart';
import 'package:emprestimos_app/models/baixa-parcela.dart';
import 'package:emprestimos_app/models/baixa_parcela_result.dart';
import 'package:emprestimos_app/models/cliente_emprestimo_ativos.dart';
import 'package:emprestimos_app/models/cobrador.dart';
import 'package:emprestimos_app/models/emprestimo.dart';
import 'package:emprestimos_app/models/parcela.dart';
import 'package:emprestimos_app/models/parcela_resumo.dart';
import 'package:emprestimos_app/models/request_emprestimo.dart';
import 'package:emprestimos_app/models/resumo_cobrador.dart';
import 'package:emprestimos_app/providers/auth_provider.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../core/api.dart';

class EmprestimoProvider with ChangeNotifier {
  bool _isLoading = false;
  AuthProvider _authProvider;
  List<ParcelaResumoDTO> _parcelas = [];
  String? _errorMessage;
  ResumoTotalizadoresEmprestimo? _resumoCliente;
  ResumoTotalizadoresEmprestimo? _resumoCobrador;
  ResumoTotalizadoresEmprestimo? _resumoEmpresa;

  bool esconderValores = true;

  List<EmprestimoDTO> _emprestimos = [];

  bool get isLoading => _isLoading;

  List<ParcelaResumoDTO> get parcelas => _parcelas;
  List<EmprestimoDTO> get emprestimos => _emprestimos;
  String? get errorMessage => _errorMessage;
  ResumoTotalizadoresEmprestimo? get resumoCobrador => _resumoCobrador;
  ResumoTotalizadoresEmprestimo? get resumoCliente => _resumoCliente;
  ResumoTotalizadoresEmprestimo? get resumoEmpresa => _resumoEmpresa;

  EmprestimoProvider(this._authProvider);

  Future<List<EmprestimoDTO>> listarEmprestimosCliente(int clienteId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response =
          await Api.dio.get("/emprestimos/cliente/$clienteId/resumo");
      final data = response.data as List<dynamic>;

      _emprestimos = data
          .map((json) => EmprestimoDTO.fromJson(json as Map<String, dynamic>))
          .toList();

      return _emprestimos;
    } catch (e) {
      print("Erro ao buscar empréstimos: $e");
      _errorMessage = "Erro ao buscar empréstimos do cliente";
      return [];
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<EmprestimoDTO?> criarEmprestimo(NovoEmprestimoDTO emprestimo) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    if (_authProvider.loginResponse!.role == "COBRADOR") {
      emprestimo.cobradorId = _authProvider.loginResponse!.usuario.id;
    }

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.post(
        "/emprestimos",
        data: emprestimo.toJson(),
      );

      if (response.statusCode != null && response.statusCode! >= 400) {
        if (response.statusCode! < 500) {
          _errorMessage = response.data.toString();
        } else {
          _errorMessage =
              "Ocorreu um erro inesperado. Tente novamente mais tarde.";
        }
        return null;
      }

      final newEmprestimo =
          EmprestimoDTO.fromJson(response.data as Map<String, dynamic>);
      return newEmprestimo;
    } on DioException catch (dioError) {
      if (dioError.response != null && dioError.response!.statusCode != null) {
        if (dioError.response!.statusCode! < 500) {
          _errorMessage = dioError.response!.data.toString();
        } else {
          _errorMessage =
              "Ocorreu um erro inesperado. Tente novamente mais tarde.";
        }
      } else {
        _errorMessage = "Erro de conexão, por favor verifique sua internet.";
      }
      return null;
    } catch (e) {
      _errorMessage = "Erro ao criar empréstimos do cliente";
      return null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  List<ParcelaDTO> get cobrancasPendentes {
    return _emprestimos
        .expand((emprestimo) => emprestimo.parcelas)
        .where((parcela) =>
            parcela.status == "PENDENTE" || parcela.status == "ATRASADA")
        .toList();
  }

  EmprestimoDTO? getEmprestimoByParcela(ParcelaDTO parcela) {
    for (var emprestimo in _emprestimos) {
      if (emprestimo.parcelas.any((p) => p.id == parcela.id)) {
        return emprestimo;
      }
    }
    return null;
  }

  Future<EmprestimoDTO?> buscarEmprestimoPorId(int emprestimoId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.get("/emprestimos/$emprestimoId");

      if (response.statusCode == 200) {
        final emprestimoAtualizado = EmprestimoDTO.fromJson(response.data);
        return emprestimoAtualizado;
      } else {
        _errorMessage = "Erro ao buscar empréstimo: ${response.statusCode}";
        return null;
      }
    } catch (e) {
      _errorMessage = "Erro inesperado ao buscar empréstimo: $e";
      return null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> buscarAllEmprestimos(Cobrador? cobrador) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    String path = "/emprestimos";

    if (cobrador != null) {
      path += '/cobrador/${cobrador.id}';
    }
    if (_authProvider.loginResponse!.role == "COBRADOR") {
      path += "/cobrador/${_authProvider.loginResponse!.usuario.id}";
    }

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.get(path);

      final apiResponse = ApiResponse<List<EmprestimoDTO>>.fromJson(
        response.data,
        (data) =>
            (data as List).map((json) => EmprestimoDTO.fromJson(json)).toList(),
      );

      if (!apiResponse.sucesso) {
        _errorMessage = apiResponse.message ?? "Erro ao buscar empréstimos.";
      } else {
        _emprestimos = apiResponse.data!;
      }

      notifyListeners();
    } catch (e) {
      _errorMessage = "Erro inesperado ao buscar empréstimo: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> buscarParcelasRelevantes() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    String cobradorOrEmpresaId =
        _authProvider.loginResponse!.usuario.id.toString();
    String path = "";

    if (_authProvider.loginResponse!.role == "COBRADOR") {
      path = '/parcelas/cobrador/$cobradorOrEmpresaId/relevantes';
    } else {
      path = '/parcelas/empresa/$cobradorOrEmpresaId/relevantes';
    }

    try {
      final response = await Api.dio.get(path);

      final apiResponse = ApiResponse<List<ParcelaResumoDTO>>.fromJson(
        response.data,
        (jsonList) => (jsonList as List)
            .map((json) => ParcelaResumoDTO.fromJson(json))
            .toList(),
      );

      if (apiResponse.sucesso) {
        _parcelas = apiResponse.data ?? [];
      } else {
        _errorMessage = apiResponse.message;
      }
    } catch (e) {
      _errorMessage = "Erro ao buscar parcelas.";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  double get somaEmprestimos {
    return _emprestimos.fold(0.0, (soma, emp) => soma + emp.valor);
  }

  Future<BaixaParcelaResult> darBaixaParcela(BaixaParcelaDTO baixaDTO) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    if (_authProvider.loginResponse!.role == "COBRADOR") {
      baixaDTO.cobradorId = _authProvider.loginResponse!.usuario.id;
    }

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.post(
        "/baixa-parcela",
        data: baixaDTO.toJson(),
      );

      final apiResponse = ApiResponse.fromJson(
        response.data,
        (json) => json,
      );

      if (!apiResponse.sucesso) {
        return BaixaParcelaResult(
          sucesso: false,
          mensagemErro: apiResponse.message,
        );
      }

      return BaixaParcelaResult(sucesso: true);
    } on DioException catch (e) {
      if (e.response != null) {
        final apiResponse = ApiResponse.fromJson(
          e.response!.data,
          (json) => json,
        );
        final mensagem = (e.response!.statusCode == 500)
            ? "Erro interno no servidor. Tente novamente mais tarde."
            : apiResponse.message;

        return BaixaParcelaResult(sucesso: false, mensagemErro: mensagem);
      } else {
        return BaixaParcelaResult(
          sucesso: false,
          mensagemErro: "Erro de conexão com o servidor.",
        );
      }
    } catch (e) {
      return BaixaParcelaResult(
        sucesso: false,
        mensagemErro: "Erro inesperado: $e",
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> buscarResumoCobrador(Cobrador? cobrador) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      int? cobradorId;
      if (cobrador != null) {
        cobradorId = cobrador.id;
      } else {
        cobradorId = _authProvider.loginResponse!.usuario.id;
      }

      final response =
          await Api.dio.get('/emprestimos/cobrador/$cobradorId/resumo');

      final apiResponse = ApiResponse<ResumoTotalizadoresEmprestimo>.fromJson(
        response.data,
        (json) => ResumoTotalizadoresEmprestimo.fromJson(
            json as Map<String, dynamic>),
      );
      if (apiResponse.sucesso) {
        _resumoCobrador = apiResponse.data;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao consutar resumo do cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> buscarResumoEmpresa() async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      String empresaId = _authProvider.loginResponse!.usuario.id.toString();

      final response =
          await Api.dio.get('/emprestimos/empresa/$empresaId/resumo');

      final apiResponse = ApiResponse<ResumoTotalizadoresEmprestimo>.fromJson(
        response.data,
        (json) => ResumoTotalizadoresEmprestimo.fromJson(
            json as Map<String, dynamic>),
      );
      if (apiResponse.sucesso) {
        _resumoEmpresa = apiResponse.data;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao consutar resumo da empresa: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<EmprestimoDTO?> quitarEmprestimoComPenhora(int emprestimoId) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final response =
          await Api.dio.post('/emprestimos/quitar-penhora/$emprestimoId');

      final apiResponse = ApiResponse<EmprestimoDTO>.fromJson(
        response.data,
        (json) => EmprestimoDTO.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso) {
        return apiResponse.data!;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao quitar empréstimo com penhora: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return null;
  }

  Future<void> buscarResumoCliente(int cliented) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final response =
          await Api.dio.get('/emprestimos/cliente/resumo/$cliented');

      final apiResponse = ApiResponse<ResumoTotalizadoresEmprestimo>.fromJson(
        response.data,
        (json) => ResumoTotalizadoresEmprestimo.fromJson(
            json as Map<String, dynamic>),
      );
      if (apiResponse.sucesso) {
        _resumoCliente = apiResponse.data;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao consutar resumo do cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void toggleEsconderValores() {
    esconderValores = !esconderValores;
    notifyListeners();
  }

  Future<ClientesEmprestimosAtivos?> countEmprestimosCliente(
      int clienteId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response =
          await Api.dio.get("/emprestimos/cliente/$clienteId/status");

      final apiResponse = ApiResponse<ClientesEmprestimosAtivos>.fromJson(
        response.data,
        (json) =>
            ClientesEmprestimosAtivos.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso == false) {
        _errorMessage = apiResponse.message;
        return null;
      }

      return apiResponse.data;
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao consultar vínculos: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return null;
  }

  void atualizarAuthProvider(AuthProvider authProvider) {
    _authProvider = authProvider;
  }

  
}
