import 'package:emprestimos_app/models/resumo_transacoes.dart';
import 'package:flutter/material.dart';
import '../models/cobranca.dart';


class CobrancaProvider with ChangeNotifier {
  List<Cobranca> _cobrancasPendentes = [];
  bool _isLoading = false;
  String? _errorMessage;
  double _percentualInadimplentes = 20.0;
  double _percentualAdimplentes = 50.0;
  double _totalRecebido = 5000.0;
  double _totalAReceber = 12000.00;
  double _totalEmprestimos = 15000.0;

  double get percentualInadimplentes => _percentualInadimplentes;
  double get percentualAdimplentes => _percentualAdimplentes;
  double get totalAReceber => _totalAReceber;
  List<ResumoTransacao> get resumoTransacoes => _resumoTransacoes;

  List<ResumoTransacao> _resumoTransacoes = [];

  List<Cobranca> get cobrancasPendentes => _cobrancasPendentes;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  double get totalRecebido => _totalRecebido;
  double get totalEmprestimos => _totalEmprestimos;

  void buscarResumoTransacoes(String filtro) {
    _isLoading = true;
    notifyListeners();

    List<ResumoTransacao> transacoes = [];

    if (filtro == "Hoje") {
      transacoes = [
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente João",
          valor: 250.00,
        ),
        ResumoTransacao(
          tipo: "emprestimo",
          descricao: "Empréstimo para Maria",
          valor: 500.00,
        ),
      ];
    } else if (filtro == "Semana") {
      transacoes = [
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente Ana",
          valor: 320.00,
        ),
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente Pedro",
          valor: 280.00,
        ),
        ResumoTransacao(
          tipo: "emprestimo",
          descricao: "Empréstimo para Carlos",
          valor: 1000.00,
        ),
      ];
    } else if (filtro == "Mês") {
      transacoes = [
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente Lucas",
          valor: 150.00,
        ),
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente Bruno",
          valor: 400.00,
        ),
        ResumoTransacao(
          tipo: "recebimento",
          descricao: "Recebimento Cliente Fernanda",
          valor: 600.00,
        ),
        ResumoTransacao(
          tipo: "emprestimo",
          descricao: "Empréstimo para Joana",
          valor: 750.00,
        ),
        ResumoTransacao(
          tipo: "emprestimo",
          descricao: "Empréstimo para Ricardo",
          valor: 1200.00,
        ),
      ];
    }

    _resumoTransacoes = transacoes;
    _isLoading = false;
    notifyListeners();
  }

  List<Cobranca> _gerarCobrancasFake(String filtro) {
    final DateTime hoje = DateTime.now();
    List<Cobranca> cobrancas = [
      Cobranca(
          id: 1,
          clienteNome: "Carlos Silva",
          valor: 500.00,
          dataVencimento: hoje,
          status: "PENDENTE"),
      Cobranca(
          id: 2,
          clienteNome: "Ana Souza",
          valor: 750.00,
          dataVencimento: hoje.add(const Duration(days: 2)),
          status: "PENDENTE"),
      Cobranca(
          id: 3,
          clienteNome: "José Oliveira",
          valor: 1200.00,
          dataVencimento: hoje.add(const Duration(days: 5)),
          status: "PENDENTE"),
      Cobranca(
          id: 4,
          clienteNome: "Fernanda Lima",
          valor: 950.00,
          dataVencimento: hoje.add(const Duration(days: 7)),
          status: "PENDENTE"),
      Cobranca(
          id: 5,
          clienteNome: "Lucas Andrade",
          valor: 400.00,
          dataVencimento: hoje.add(const Duration(days: 1)),
          status: "ATRASADO"),
      Cobranca(
          id: 6,
          clienteNome: "Juliana Alves",
          valor: 1300.00,
          dataVencimento: hoje.add(const Duration(days: 3)),
          status: "PAGO"),
      Cobranca(
          id: 7,
          clienteNome: "Fernando Borges",
          valor: 2100.00,
          dataVencimento: hoje.add(const Duration(days: 4)),
          status: "PENDENTE"),
      Cobranca(
          id: 8,
          clienteNome: "Bruna Castro",
          valor: 850.00,
          dataVencimento: hoje.add(const Duration(days: 6)),
          status: "ATRASADO"),
      Cobranca(
          id: 9,
          clienteNome: "Marcos Paulo",
          valor: 700.00,
          dataVencimento: hoje.add(const Duration(days: 9)),
          status: "PENDENTE"),
      Cobranca(
          id: 10,
          clienteNome: "Bianca Moura",
          valor: 1100.00,
          dataVencimento: hoje.add(const Duration(days: 12)),
          status: "PAGO"),
    ];

    // Filtrar cobranças conforme o período selecionado
    switch (filtro) {
      case "Hoje":
        return cobrancas
            .where((c) => c.dataVencimento.isAtSameMomentAs(hoje))
            .toList();
      case "Semana":
        return cobrancas
            .where((c) =>
                c.dataVencimento.isBefore(hoje.add(const Duration(days: 7))))
            .toList();
      case "Mês":
        return cobrancas;
      default:
        return cobrancas;
    }
  }

  Future<void> buscarCobrancas(String filtroPeriodo) async {
    _isLoading = true;
    notifyListeners();

    // Simulando um delay de carregamento
    await Future.delayed(const Duration(seconds: 2));

    // Gerando cobranças fake para teste
    _cobrancasPendentes = _gerarCobrancasFake(filtroPeriodo);

    _calcularValoresResumo(filtroPeriodo);

    _isLoading = false;
    notifyListeners();
  }

  void _calcularValoresResumo(String filtro) {
    if (filtro == "Hoje") {
      _totalAReceber = 4000.00;
      _totalRecebido = 1500.00;
      _totalEmprestimos = 5000.00;
    } else if (filtro == "Semana") {
      _totalAReceber = 12000.00;
      _totalRecebido = 8000.00;
      _totalEmprestimos = 18000.00;
    } else {
      _totalAReceber = 22000.00;
      _totalRecebido = 12000.00;
      _totalEmprestimos = 35000.00;
    }
  }

  // Future<void> buscarCobrancas(String periodo) async {
  //   _isLoading = true;
  //   _errorMessage = null;
  //   notifyListeners();

  //   try {
  //     await Api.loadAuthToken();
  //     final Response response = await Api.dio.get("/cobrancas", queryParameters: {"periodo": periodo});

  //     final apiResponse = ApiResponse<List<Cobranca>>.fromJson(
  //       response.data,
  //       (jsonList) => (jsonList as List)
  //           .map((e) => Cobranca.fromJson(e as Map<String, dynamic>))
  //           .toList(),
  //     );

  //     if (apiResponse.sucesso) {
  //       _cobrancasPendentes = apiResponse.data!;
  //     } else {
  //       _errorMessage = apiResponse.message;
  //     }
  //   } on DioException catch (dioErr) {
  //     _errorMessage = "Erro ao buscar cobranças: ${dioErr.response?.data ?? dioErr.message}";
  //   } catch (e) {
  //     _errorMessage = "Erro inesperado: $e";
  //   } finally {
  //     _isLoading = false;
  //     notifyListeners();
  //   }
  // }
}
