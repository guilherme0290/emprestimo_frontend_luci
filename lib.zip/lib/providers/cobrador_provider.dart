import 'package:emprestimos_app/models/cliente_emprestimo_ativos.dart';
import 'package:emprestimos_app/models/resumo_cobrador.dart';
import 'package:emprestimos_app/providers/auth_provider.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../core/api.dart';
import '../core/dio_error_handler.dart';
import '../models/cobrador.dart';
import '../models/api_response.dart';

class CobradorProvider with ChangeNotifier {
  List<Cobrador> _cobradores = [];
  bool _isLoading = false;
  String? _errorMessage;
  String? _sucessMessage;
  AuthProvider _authProvider;
  ResumoTotalizadoresEmprestimo? _resumoCobrador;
  bool esconderValores = true;

  String? get errorMessage => _errorMessage;
  String? get sucessMessage => _sucessMessage;
  List<Cobrador> get cobradores => _cobradores;
  bool get isLoading => _isLoading;
  ResumoTotalizadoresEmprestimo? get resumoCobrador => _resumoCobrador;

  CobradorProvider(this._authProvider);

  String getNomeCobrador() {
    String nomeCobrador;
    try {
      nomeCobrador = _authProvider.loginResponse!.usuario.nome.split(' ')[0];
    } catch (e) {
      nomeCobrador = "Usuário";
    }
    return nomeCobrador;
  }

  Future<void> listarCobradores() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.get("/cobradores");

      final apiResponse = ApiResponse<List<Cobrador>>.fromJson(
        response.data,
        (jsonList) => (jsonList as List)
            .map((e) => Cobrador.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

      if (apiResponse.sucesso) {
        _cobradores = apiResponse.data!;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao listar cobradores: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> transferirEmprestimos({
    required int cobradorDesligadoId,
    required int novoCobradorId,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    _sucessMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.post(
        "/cobradores/$cobradorDesligadoId/inativar",
        data: {"novoCobradorId": novoCobradorId},
      );

      final apiResponse = ApiResponse<bool>.fromJson(
        response.data,
        (json) => json as bool,
      );

      if (apiResponse.sucesso) {
        _sucessMessage =
            apiResponse.message ?? "Transferência realizada com sucesso.";
        return true;
      } else {
        _errorMessage = apiResponse.message ?? "Falha na transferência.";
        return false;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
      return false;
    } catch (e) {
      _errorMessage = "Erro inesperado ao transferir empréstimos: $e";
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }


  /// Buscar um cobrador pelo ID
  Future<Cobrador?> buscarCobrador(int id) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.get("/cobradores/$id");

      final apiResponse = ApiResponse<Cobrador>.fromJson(
        response.data,
        (json) => Cobrador.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso) {
        return apiResponse.data;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao buscar cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }

    return null;
  }

  /// Criar um novo cobrador
  Future<bool> criarCobrador(Cobrador cobrador) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.post(
        "/cobradores",
        data: cobrador.toJson(),
      );

      final apiResponse = ApiResponse<Cobrador>.fromJson(
        response.data,
        (json) => Cobrador.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso) {
        _sucessMessage = apiResponse.message;
        await listarCobradores();
        return true;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao criar cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }

    return false;
  }

  /// Atualizar um cobrador existente
  Future<bool> atualizarCobrador(Cobrador cobrador) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.put(
        "/cobradores/${cobrador.id}",
        data: cobrador.toJson(),
      );

      final apiResponse = ApiResponse<Cobrador>.fromJson(
        response.data,
        (json) => Cobrador.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso) {
        _sucessMessage = apiResponse.message;
        return true;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao atualizar cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }

    return false;
  }

  /// Excluir um cobrador
  Future<bool> excluirCobrador(int cobradorId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Api.loadAuthToken();
      final response = await Api.dio.delete("/cobradores/$cobradorId");

      final apiResponse = ApiResponse<bool>.fromJson(
        response.data,
        (json) => json as bool,
      );

      if (apiResponse.sucesso) {
        await listarCobradores();
        return true;
      } else {
        _errorMessage = apiResponse.message;
      }
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao excluir cobrador: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }

    return false;
  }

  Future<ClientesEmprestimosAtivos?> consultarVinculosCobrador(
      int cobradorId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response =
          await Api.dio.get("/cobradores/$cobradorId/vinculos-ativos");

      final apiResponse = ApiResponse<ClientesEmprestimosAtivos>.fromJson(
        response.data,
        (json) =>
            ClientesEmprestimosAtivos.fromJson(json as Map<String, dynamic>),
      );

      if (apiResponse.sucesso == false) {
        _errorMessage = apiResponse.message;
        return null;
      }

      return apiResponse.data;
    } on DioException catch (dioErr) {
      _errorMessage = DioErrorHandler.handleDioException(dioErr);
    } catch (e) {
      _errorMessage = "Erro inesperado ao consultar vínculos: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return null;
  }

  
  void atualizarAuthProvider(AuthProvider authProvider) {
    _authProvider = authProvider;
  }
}
