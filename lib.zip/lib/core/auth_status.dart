enum AuthStatus { carregando, autenticado, naoAutenticado }
