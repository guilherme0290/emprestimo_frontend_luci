enum StatusEmprestimosEnum {
  ATIVO,
  QUITADO,
  ATRASADO;
}
