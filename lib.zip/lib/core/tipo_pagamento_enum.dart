enum TipoPagamentoEnum { DIARIO, SEMANAL, QUINZENAL, MENSAL }
