import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:emprestimos_app/core/navigation_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static String urlProducao = "https://api.gestaoemprestimos.com.br/api";
  static String urlHomologacao = "http://192.168.100.100:8080/api";
  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: urlProducao, // Alterar para o IP do servidor
      connectTimeout: const Duration(seconds: 1000),
      receiveTimeout: const Duration(seconds: 1000),
    ),
  );

  static Future<void> setAuthToken(String token) async {
    _dio.options.headers["Authorization"] = token;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString("jwt_token", token);
  }

  static Future<void> loadAuthToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("jwt_token");
    if (token != null) {
      _dio.options.headers["Authorization"] = token;
    }
  }

  // Adicionando Interceptor para garantir que o token esteja sempre presente
  static void addInterceptor() {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          String? token = prefs.getString("jwt_token");

          if (token != null &&
              !options.path.contains('/login') &&
              !options.path.contains('/recuperar-senha') &&
              !options.path.contains('/planos') &&
              !options.path.contains('/noauth')) {
            options.headers["Authorization"] = token;
          }

          if (options.method != 'GET' && options.data != null) {
            options.headers["Content-Type"] = "application/json";
          }

          print(
              "🔹 Requisição para: ${options.method} ${options.baseUrl}${options.path}");
          print("📌 Headers: ${options.headers}");
          print("📨 Body: ${jsonEncode(options.data)}");

          return handler.next(options);
        },
        onResponse: (response, handler) {
          print("✅ Resposta recebida [${response.statusCode}]");

          if (response.data is Map || response.data is List) {
            print("📦 Conteúdo: ${response.data}");
          } else {
            print(
                "⚠️ Tipo de resposta inesperado: ${response.data.runtimeType}");
          }

          return handler.next(response);
        },
        onError: (DioException e, handler) {
          if (e.response?.statusCode == 401) {
            final context = navigatorKey.currentContext;

            if (context != null) {
              // ScaffoldMessenger.of(context).showSnackBar(
              //   const SnackBar(
              //       content: Text("Sessão expirada.")),
              // );

              navigatorKey.currentState?.pushNamedAndRemoveUntil(
                '/login',
                (route) => false,
              );
            }
          }

          print("❌ Erro na requisição: ${e.message}");
          return handler.next(e);
        },
      ),
    );
  }

  static Dio get dio {
    addInterceptor();
    _dio.toString();
    return _dio;
  }
}
