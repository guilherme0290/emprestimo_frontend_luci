enum StatusParcelaEnum {
  PENDENTE,
  ATRASADA,
  PAGA;
}
