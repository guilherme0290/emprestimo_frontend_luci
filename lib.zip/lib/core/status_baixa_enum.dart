enum StatusBaixaEnum {
  JUROS,
  PARCIAL,
  TOTAL,
  QUITADA;
}
